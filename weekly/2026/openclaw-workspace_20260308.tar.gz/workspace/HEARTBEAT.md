# HEARTBEAT.md - 定时任务清单

## 每日任务

### 17:00 - 核心配置备份

- **任务**：备份 SOUL.md, MEMORY.md, AGENTS.md 到 GitHub
- **脚本**：`~/.openclaw/scripts/backup-daily.sh`
- **目标仓库**：https://github.com/fisher0000/openclaw-backup
- **备份内容**：
  - `daily/YYYY/MM/SOUL_YYYYMMDD.md`
  - `daily/YYYY/MM/MEMORY_YYYYMMDD.md`
  - `daily/YYYY/MM/AGENTS_YYYYMMDD.md`
  - `latest/`（最新版本）
- **触发时间**：每天 17:00

---

## 每周任务

### 周五 17:00 - Workspace 完整备份

- **任务**：打包整个 workspace 到 GitHub
- **脚本**：`~/.openclaw/scripts/backup-weekly.sh`
- **目标仓库**：https://github.com/fisher0000/openclaw-backup
- **备份内容**：
  - `weekly/YYYY/openclaw-workspace_YYYYMMDD.tar.gz`
  - 保留最近4周的备份
- **触发时间**：每周五 17:00

---

## 多Agent系统状态

### Agent列表：

| Agent | 状态 | 最后活跃 |
|-------|------|----------|
| 小虾（主控） | ✅ 活跃 | 实时 |
| 情报搜集专家 | ✅ 就绪 | 等待任务 |
| 报告撰写专家 | ✅ 就绪 | 等待任务 |
| 化学合成专家 | ✅ 就绪 | 等待任务 |

### 工作流状态：

- **配置文件：** ~/.openclaw/agents/config.yaml
- **启动脚本：** ~/.openclaw/agents/multi-agent.sh
- **架构文档：** ~/.openclaw/agents/README.md

---

## 状态追踪

- 当前任务执行状态记录在 `~/.openclaw/workspace/STATE.yaml`
- 多Agent系统状态记录在 `~/.openclaw/agents/config.yaml`

---

## 🔧 备份任务配置

### Cron 配置文件
- **路径**：`~/.openclaw/cron/backup-tasks.toml`

### 备份脚本
- **每日备份**：`~/.openclaw/scripts/backup-daily.sh`
- **每周备份**：`~/.openclaw/scripts/backup-weekly.sh`

### 注意事项
1. 需要配置 GitHub 认证（SSH key 或 Personal Access Token）
2. 首次运行前请确保目标仓库已创建并可访问
3. 备份日志可通过 OpenClaw 日志查看
