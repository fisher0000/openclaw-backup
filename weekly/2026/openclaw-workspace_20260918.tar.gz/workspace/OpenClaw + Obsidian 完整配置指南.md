# 📚 OpenClaw + Obsidian 完整配置指南

> ✅ **前提条件**：OpenClaw 已安装并运行

---

## 📋 目录

1. [安装 Obsidian](#1-安装-obsidian)
2. [安装 Markitdown File Converter 插件](#2-安装-markitdown-file-converter-插件)
3. [安装 Obsidian Git 插件](#3-安装-obsidian-git-插件)
4. [安装 Obsidian CLI](#4-安装-obsidian-cli)
5. [安装 OpenClaw 的 Obsidian 技能](#5-安装-openclaw-的-obsidian-技能)
6. [验证与测试](#6-验证与测试)
7. [快速安装脚本](#7-快速安装脚本)

---

## 1️⃣ 安装 Obsidian

### 方法 1：官网下载（推荐）

```powershell
# 访问官网下载
https://obsidian.md/download

# 选择对应系统版本：
# Windows → Download for Windows
# macOS → Download for macOS
# Linux → 选择对应包管理器
```




### 方法 2：通过包管理器安装

| 系统 | 命令 |
|------|------|
| **Windows** | `winget install Obsidian` |
| **macOS** | `brew install --cask obsidian` |
| **Linux** | `sudo apt install obsidian` |



### ✅ 验证安装

```powershell
# Windows 检查安装
where obsidian
obsidian --version

# 确认 Obsidian 可以正常打开
```




---

## 2️⃣ 安装 Markitdown File Converter 插件

### 安装步骤（图形界面操作）

```
┌─────────────────────────────────────────────────────┐
│  1. 打开 Obsidian                                    │
│  2. 点击左下角 ⚙️ 设置（Settings）                    │
│  3. 进入 "社区插件"（Community Plugins）               │
│  4. 关闭 "受限模式"（Restricted Mode）                │
│  5. 点击 "浏览商店"（Browse）                         │
│  6. 搜索 "Markitdown" 或 "Markitdown File Converter"  │
│  7. 点击 "安装"（Install）                            │
│  8. 点击 "启用"（Enable）                             │
└─────────────────────────────────────────────────────┘
```




### 🔧 插件配置（可选）

| 配置项 | 推荐设置 |
|--------|----------|
| **Source formats** | PDF, DOCX, EPUB, Images |
| **Output location** | 同目录或指定目录 |
| **Embed images** | 根据需要开启 |

---

### 📄 转换文件示例

```
方法：
1. 将 PDF/Word 文件放入 Vault 目录
2. 右键点击文件
3. 选择 "Markitdown: Convert to Markdown"
4. 转换后的 Markdown 文件会自动生成
```




---

## 3️⃣ 安装 Obsidian Git 插件

### 安装步骤（图形界面操作）

```
┌─────────────────────────────────────────────────────┐
│  1. 打开 Obsidian                                    │
│  2. 点击左下角 ⚙️ 设置（Settings）                    │
│  3. 进入 "社区插件"（Community Plugins）               │
│  4. 关闭 "受限模式"（Restricted Mode）                │
│  5. 点击 "浏览商店"（Browse）                         │
│  6. 搜索 "Git"                                        │
│  7. 选择 "Git" 插件（由 Timothin D 或 similar 开发）     │
│  8. 点击 "安装"（Install）                            │
│  9. 点击 "启用"（Enable）                             │
│ 10. 重启 Obsidian                                    │
└─────────────────────────────────────────────────────┘
```




### 🔧 Git 配置步骤

```
1. 启用 Git 插件后，点击插件设置图标

2. 配置远程仓库：
   - Remote URL: 输入你的 Git 仓库地址
     示例：https://github.com/username/repo.git
   或
     示例：https://gitee.com/username/repo.git

3. 配置自动提交（可选）：
   - 勾选 "Auto Commit"
   - 设置提交频率

4. 初始化仓库：
   - 点击 "Init" 按钮初始化本地 Git 仓库

5. 首次推送：
   - 点击 "Push" 将仓库推送到远程
```




### ⚙️ 远程仓库配置（命令行辅助）

```powershell
# 如果插件提示需要配置，使用命令行设置 Git
cd "你的 Obsidian Vault 路径"

# 初始化 Git 仓库
git init

# 添加远程仓库
git remote add origin https://github.com/你的用户名/仓库名.git

# 拉取远程仓库（如果已存在）
git pull origin main

# 配置 Git 用户信息
git config --global user.name "你的用户名"
git config --global user.email "你的邮箱@example.com"
```



---

## 4️⃣ 安装 Obsidian CLI

### 安装方法

| 方法 | 命令 |
|------|------|
| **npm 安装（Windows/macOS/Linux）** | `npm install -g obsidian-cli` |
| **国内镜像加速** | `npm config set registry https://registry.npmmirror.com ` <br> `npm install -g obsidian-cli` |
| **winget 安装（Windows）** | `winget install yakitrak.obsidian-cli` |
| **brew 安装（macOS）** | `brew install obsidian-cli` |



### ✅ 验证安装

```powershell
# 检查版本
obsidian --version

# 查看帮助
obsidian --help

# 测试打开 Obsidian
obsidian --open
```




---

## 5️⃣ 安装 OpenClaw 的 Obsidian 技能

### 方法 1：使用 clawhub 安装（推荐）

```powershell
# 1. 安装 Obsidian 相关技能
clawhub install obsidian-sync obsidian-parser markdown-formatter --force

# 2. 或者使用 openclaw 命令
openclaw plugin install obsidian
```



### 方法 2：搜索并安装

```powershell
# 搜索可用技能
openclaw plugin search obsidian

# 安装指定技能
openclaw plugin install obsidian-sync
openclaw plugin install obsidian-parser
```



### ⚙️ 配置 Vault 路径（简单配置）

```powershell
# Windows 示例
openclaw config set obsidian.vaultPath "C:\Users\你的用户名\Documents\Obsidian\MyVault"

# macOS/Linux 示例
openclaw config set obsidian.vaultPath "/Users/你的用户名/Documents/Obsidian/MyVault"

# 查看配置
openclaw config get obsidian.vaultPath
```




---

## 6️⃣ 验证与测试

### 完整验证清单

| 检查项 | 命令 | 预期结果 |
|--------|------|----------|
| ✅ Obsidian 安装 | `obsidian --version` | 显示版本号 |
| ✅ Markitdown 插件 | Obsidian 插件列表查看 | 显示已安装 |
| ✅ Git 插件 | Obsidian 插件列表查看 | 显示已安装 |
| ✅ Obsidian CLI | `obsidian --open` | 成功打开 Obsidian |
| ✅ OpenClaw 运行 | `openclaw --version` | 显示版本信息 |
| ✅ Obsidian 技能 | `openclaw plugin list` | 显示 obsidian-* 技能 |
| ✅ Vault 路径配置 | `openclaw config get obsidian.vaultPath` | 显示配置的路径 |

---

### 功能测试

```powershell
# === 测试 Obsidian CLI ===
# 打开 Obsidian
obsidian --open

# 打开指定笔记（如果存在）
obsidian --open "README.md"

# === 测试 OpenClaw 技能 ===
# 查看技能列表
openclaw plugin list

# 测试调用 Obsidian（示例命令）
openclaw call obsidian.open "测试笔记"

# === 测试 Git 同步 ===
# 在 Obsidian 中点击 Git 插件的 "Init" 按钮
# 然后手动 push 到远程仓库
```



---

## 7️⃣ 快速安装脚本（一键完成）

### Windows PowerShell 脚本

```powershell
# === OpenClaw + Obsidian 一键安装脚本 ===
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  OpenClaw + Obsidian 快速配置指南" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: 安装 Obsidian CLI
Write-Host "[1/5] 安装 Obsidian CLI..." -ForegroundColor Yellow
$cliInstalled = $false
try {
    obsidian --version > $null 2>&1
    $cliInstalled = $true
    Write-Host "✅ Obsidian CLI 已安装" -ForegroundColor Green
} catch {
    npm install -g obsidian-cli
    if (obsidian --version) {
        Write-Host "✅ Obsidian CLI 安装成功" -ForegroundColor Green
    } else {
        Write-Host "❌ Obsidian CLI 安装失败，请手动安装" -ForegroundColor Red
    }
}

# Step 2: 验证 Obsidian 应用
Write-Host "[2/5] 检查 Obsidian 应用..." -ForegroundColor Yellow
try {
    obsidian --version > $null 2>&1
    Write-Host "✅ Obsidian 应用已安装" -ForegroundColor Green
} catch {
    Write-Host "⚠️ 请先从官网下载并安装 Obsidian：https://obsidian.md" -ForegroundColor Yellow
}

# Step 3: 安装 OpenClaw 技能
Write-Host "[3/5] 安装 OpenClaw Obsidian 技能..." -ForegroundColor Yellow
try {
    clawhub install obsidian-sync obsidian-parser --force > $null 2>&1
    Write-Host "✅ OpenClaw 技能安装成功" -ForegroundColor Green
} catch {
    Write-Host "⚠️ 请手动执行：clawhub install obsidian-sync --force" -ForegroundColor Yellow
}

# Step 4: 获取 Vault 路径
Write-Host "[4/5] 配置 Vault 路径..." -ForegroundColor Yellow
$defaultVault = "C:\Users\$env:USERNAME\Documents\Obsidian\MyVault"
$vaultPath = Read-Host "请输入你的 Obsidian Vault 路径 (默认：$defaultVault)"
if ([string]::IsNullOrEmpty($vaultPath)) {
    $vaultPath = $defaultVault
}

# 创建配置
openclaw config set obsidian.vaultPath $vaultPath
Write-Host "✅ Vault 路径配置：$vaultPath" -ForegroundColor Green

# Step 5: 验证安装
Write-Host "[5/5] 验证安装..." -ForegroundColor Yellow
Write-Host ""
Write-Host "=== 配置完成！=== " -ForegroundColor Green
Write-Host "下一步操作：" -ForegroundColor Cyan
Write-Host "  1. 打开 Obsidian，安装 Markitdown File Converter 插件" -ForegroundColor Yellow
Write-Host "  2. 打开 Obsidian，安装 Git 插件并配置远程仓库" -ForegroundColor Yellow
Write-Host "  3. 验证 OpenClaw 技能：openclaw plugin list" -ForegroundColor Yellow
Write-Host ""
Write-Host "=== 配置完成！=== " -ForegroundColor Green
```



---

## 📊 完整配置流程图

```
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw + Obsidian 配置流程               │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   Step 1: 安装 Obsidian 应用  →  官网下载                    │
│                         ↓                                   │
│   Step 2: 安装 Markitdown 插件 → 社区插件商店               │
│                         ↓                                   │
│   Step 3: 安装 Git 插件      → 社区插件商店                 │
│                         ↓                                   │
│   Step 4: 安装 Obsidian CLI  → 命令行安装                   │
│                         ↓                                   │
│   Step 5: 安装 OpenClaw 技能   → clawhub install            │
│                         ↓                                   │
│   Step 6: 配置 Vault 路径    → openclaw config set          │
│                         ↓                                   │
│   Step 7: 验证功能         → 测试命令运行                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```




---

## 🎯 快速命令参考

| 功能 | 命令 |
|------|------|
| 打开 Obsidian | `obsidian --open` |
| 打开特定笔记 | `obsidian --open "笔记名.md"` |
| 创建新笔记 | `obsidian --create "新笔记"` |
| 查看 Vault 配置 | `openclaw config get obsidian.vaultPath` |
| 设置 Vault 路径 | `openclaw config set obsidian.vaultPath "路径"` |
| 查看插件列表 | `openclaw plugin list` |
| 搜索插件 | `clawhub search obsidian` |
| 安装插件 | `clawhub install obsidian-sync --force` |

---

## ⚠️ 常见问题

| 问题 | 解决方案 |
|------|----------|
| **obsidian 命令找不到** | 检查 npm 全局路径是否添加到 PATH |
| **插件商店无法访问** | 检查网络连接，或手动从 GitHub 下载 |
| **Git 插件无法连接远程** | 检查网络代理设置 |
| **Vault 路径配置错误** | 使用 `openclaw config set obsidian.vaultPath "正确路径"` |

---

## 📚 官方资源

| 资源 | 链接 |
|------|------|
| Obsidian 官网 | https://obsidian.md/   |
| OpenClaw | https://clawcn.net/   |
| Obsidian CLI | https://github.com/davidrusu/obsidian-cli   |
| Markitdown 插件 | Obsidian 社区插件商店 |
| Obsidian Git 插件 | Obsidian 社区插件商店 |

---

**配置完成！祝你使用愉快！** 🎉