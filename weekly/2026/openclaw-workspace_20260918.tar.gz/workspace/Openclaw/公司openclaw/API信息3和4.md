提供方：livzon
接口地址：https://newapi.livzon.cn/v1
秘钥：sk-9ID0HkOPnLxZasRlMeiDgZgt6QkGO4RUG8BdoqKPBW2Wep5q
模型ID：deepseek-v4-pro



提供方：livzon
接口地址：https://newapi.livzon.cn/v1
秘钥：sk-9ID0HkOPnLxZasRlMeiDgZgt6QkGO4RUG8BdoqKPBW2Wep5q
模型ID：deepseek-v4-flash
