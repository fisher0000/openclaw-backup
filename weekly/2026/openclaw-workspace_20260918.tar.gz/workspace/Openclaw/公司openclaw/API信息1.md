MiniMax
"id": "MiniMax-M2.5",
"baseUrl": "https://newapi.livzon.cn/v1",
"apiKey": sk-9ID0HkOPnLxZasRlMeiDgZgt6QkGO4RUG8BdoqKPBW2Wep5q
"api": "openai-completions"

/model livzon/MiniMax-M2.5   


```
      "livzon": {
        "baseUrl": "https://newapi.livzon.cn/v1",
        "apiKey": "sk-9ID0HkOPnLxZasRlMeiDgZgt6QkGO4RUG8BdoqKPBW2Wep5q",
        "api": "openai-completions",
        "models": [
          {
            "id": "MiniMax-M2.5",
            "name": "MiniMax-M2.5 (Custom Provider)",
            "reasoning": false,
            "input": [
              "text"
            ],
            "cost": {
              "input": 0,
              "output": 0,
              "cacheRead": 0,
              "cacheWrite": 0
            },
            "contextWindow": 256000,
            "maxTokens": 16000,
            "api": "openai-completions"
          }
        ]
      }
```

@所有人 **重要！**相关api信息只能留在我们子公司内部。

- 添加新模型后，需要输入
    

```
/model livzon/MiniMax-M2.5
```

从而切换模型。

- 能聊天后，要求openclaw将默认模型改为livzon/MiniMax-M2.5。


