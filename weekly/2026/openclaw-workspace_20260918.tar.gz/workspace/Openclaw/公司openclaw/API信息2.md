提供方：moonshot
接口地址：[https://api.moonshot.cn/v1](https://api.moonshot.cn/v1)
秘钥：sk-uKJpmccGfrRAqaK5lA0ZCIDXP9gvJnyruSZm1jP7WAvM3QD9
模型ID：kimi-k2.5



@所有人 ，集团提供的moonshot模型已恢复使用，鼓励大家优先使用moonshot的模型，在遇到问题时再切换回今天提供的其它模型。

```
      "moonshot": {
        "baseUrl": "https://api.moonshot.cn/v1",
        "apiKey": "sk-uKJpmccGfrRAqaK5lA0ZCIDXP9gvJnyruSZm1jP7WAvM3QD9",
        "api": "openai-completions",
        "models": [
          {
            "id": "kimi-k2.5",
            "name": "kimi-k2.5",
            "reasoning": false,
            "input": [
              "text",
              "image"
            ],
            "cost": {
              "input": 0,
              "output": 0,
              "cacheRead": 0,
              "cacheWrite": 0
            },
            "contextWindow": 256000,
            "maxTokens": 8192
          }
        ]
      },
```

提供方：moonshot

接口地址：[https://api.moonshot.cn/v1](https://api.moonshot.cn/v1)

秘钥：sk-uKJpmccGfrRAqaK5lA0ZCIDXP9gvJnyruSZm1jP7WAvM3QD9

模型ID：kimi-k2.5




