| pubs.acs.org/OPRD   |     |     |     |     |                |     |                |              |         |     |         |     | Article |
| ------------------- | --- | --- | --- | --- | -------------- | --- | -------------- | ------------ | ------- | --- | ------- | --- | ------- |
| Development         |     |     | of  | a   | Novel          |     | Chemoenzymatic |              | Process |     | for     |     |         |
| 3‑(Methylsulfonyl)‑ |     |     |     |     | ‑phenylalanine |     |                | Phenylmethyl |         |     | Ester�A | Key |         |
L
| Intermediate |     |     | of  | Lifitegrast |     |     | (Xiidra) |     |     |     |     |     |     |
| ------------ | --- | --- | --- | ----------- | --- | --- | -------- | --- | --- | --- | --- | --- | --- |
Chuanjun Wu, Heng Guo, Jiawei Tang, Lintao Xia, Jianfen Shao, Yongfu He, Fei Chen, Peng Peng,
| Yuewen                                      | Han, | Chuanmeng |     | Zhao,* |     | Fuli | Zhang,* and | Shaoxin    | Chen* |     |     |     |     |
| ------------------------------------------- | ---- | --------- | --- | ------ | --- | ---- | ----------- | ---------- | ----- | --- | --- | --- | --- |
| CiteThis:Org.ProcessRes.Dev.2024,28,693−703 |      |           |     |        |     |      |             | ReadOnline |       |     |     |     |     |
.)CTU( 45:52:61 ta 5202 ,03 hcraM no NCDEM NIHC LANOITIDART VINU GNIJNAN aiv dedaolnwoD
.selcitra dehsilbup erahs yletamitigel ot woh no snoitpo rof senilediuggnirahs/gro.sca.sbup//:sptth eeS
ACCESS Metrics&More ArticleRecommendations * SupportingInformation
sı
ABSTRACT: In the present study, a practical chemoenzymatic method was developed for the synthesis of chiral phenylalanine
derivative1,whichisthekeyintermediateofLifitegrast.Inthisestablishedprocess,asimpleandeffectiveZn/HClreductionsystem
was employed to obtain N-acetyl-3-bromo-phenylalanine 6, which served as the substrate for the subsequent enzymatic resolution
process. Then, the key chiral intermediate, 3-bromo-L-phenylalanine 7, could be obtained using acylase (ACY) AmACY. Upon
processoptimization,thechemicalreactionwasexecutedata300gscale,withanotablesubstrateconcentrationreachingupto100
g/L.Theprocessachievedayieldof 40%,comparedtoamaximumtheoreticalyieldof50%, andexhibitedanenantiomericexcess
(ee) value reaching up to 99.9%. A simple and effective Zn/HCl reduction system was employed to obtain N-acetyl-3-bromo-
phenylalanine 6, which served as the substrate for the subsequent enzymatic resolution process. This synthetic pathway was
effectively executed, yielding 1·HCl with a purity of 99.7% and an ee value of 99.9%, culminating in an overall yield of 23.4%.
Additionally,theundesired(D)-6enantiomerwasrecycledtoform(rac)-6,employinganacetanhydride/aceticacid(Ac O/AcOH)
2
system.Thisrecyclingprocessachievedayieldof47.5%,relativetoamaximumtheoreticalyieldof50%,andapuritylevelof99.8%.
KEYWORDS: Lifitegrast, enzymatic resolution, phenylalanine derivatives, synthesis process
| ■            |     |     |     |     |     |     |     | ■       |     |            |     |     |     |
| ------------ | --- | --- | --- | --- | --- | --- | --- | ------- | --- | ---------- | --- | --- | --- |
| INTRODUCTION |     |     |     |     |     |     |     | RESULTS | AND | DISCUSSION |     |     |     |
Lifitegrast, developed by Shire, serves as an innovative small- AsshowninScheme2,theresultsoftheretrosyntheticanalysis
| molecule | inhibitor | targeting |     | integrin | receptors.1 |     | In 2016, |                                   |     |     |          |      |            |
| -------- | --------- | --------- | --- | -------- | ----------- | --- | -------- | --------------------------------- | --- | --- | -------- | ---- | ---------- |
|          |           |           |     |          |             |     |          | of N-acetyl-3-bromo-phenylalanine |     |     | 6 reveal | that | 6 could be |
Lifitegrast(Xiidra)wasapprovedbytheFDAforthetreatment accessed by the selective reduction of propenoic acid
of xerophthalmia. intermediate 5. Intermediate 5 could be readily derived
Lifitegrast as shown in Figure 1 is composed of three Erlenmeyer−Plöchl
|     |     |     |     |     |     |     |     | through | the |     | reaction | of 3-bromobenzalde- |     |
| --- | --- | --- | --- | --- | --- | --- | --- | ------- | --- | --- | -------- | ------------------- | --- |
fragments, namely, benzofuran fragment, tetrahydroisoquino- hydrolysis.6
|     |     |     |     |     |     |     |     | hyde 2 and | subsequent |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | ---------- | ---------- | --- | --- | --- | --- |
line fragment, and the chiral phenylalanine fragment 1 (1748 In summary, a scalable, novel chemoenzymatic route was
$/kg, http://www.mic-pharma.com/). As such, the develop- designed for preparing 3-(methylsulfonyl)-phenylmethyl ester
| ment of | an efficient |     | synthesis | of  | the enantiopure |     | 1 is of |               |        |          |           |     |     |
| ------- | ------------ | --- | --------- | --- | --------------- | --- | ------- | ------------- | ------ | -------- | --------- | --- | --- |
|         |              |     |           |     |                 |     |         | hydrochloride | 1·HCl, | as shown | in Scheme | 3.  |     |
considerable significance in the synthesis of Lifitegrast. Optimization of the Erlenmeyer−Plöchl Reaction (2
Theexistingsynthesisroutesofcompound1areplaguedby to 5). To determine the feasibility of this route, cheap 3-
| several limitations |               | including |                   | suboptimal | enantiomeric |     | purity, |                       |     |       |                                |     |     |
| ------------------- | ------------- | --------- | ----------------- | ---------- | ------------ | --- | ------- | --------------------- | --- | ----- | ------------------------------ | --- | --- |
|                     |               |           |                   |            |              |     |         | bromo-benzaldehyde    |     | 2 (63 | $/kg, https://www.whmall.com/) |     |     |
| elevated            | cost factors, |           | and operationally |            | cumbersome   |     | proce-  |                       |     |       |                                |     |     |
|                     |               |           |                   |            |              |     |         | and N-acetyl−glycine3 |     | (18   | $/kg, https://www.whmall.com/) |     |     |
1·
dures. In 2012, Shire Co. reported a method for obtaining were selected as raw materials4−6 to prepare compound 4,
| HCl, which | involved |     | using | 3-bromo-L-phenylalanine |     |     | 7 (280 |     |     |     |     |     |     |
| ---------- | -------- | --- | ----- | ----------------------- | --- | --- | ------ | --- | --- | --- | --- | --- | --- |
followedbyhydrolysisusingHCltoprovidecompound5ina
$/100g,reagentgrade,https://www.sigmaaldrich.cn/CN/en)
|          |           |           |         |            |        |          |          | moderate     | yield. However, |        | the formation | of compound | 5 was |
| -------- | --------- | --------- | ------- | ---------- | ------ | -------- | -------- | ------------ | --------------- | ------ | ------------- | ----------- | ----- |
| as the   | starting  | material  | (Scheme |            | 1a).2  | However, | starting |              |                 |        |               |             |       |
|          |           |           |         |            |        |          |          | concurrently | observed        | during | the synthesis | of compound | 4.    |
| material | 7 was not | available |         | on a large | scale, | thereby  | limiting |              |                 |        |               |             |       |
Theresultsofthecontrolstudiesindicatedthatthehydrolysis
| the widespread |           | application        | of  | this       | strategy.    | Wang      | et al. used |             |                |                |       |             |          |
| -------------- | --------- | ------------------ | --- | ---------- | ------------ | --------- | ----------- | ----------- | -------------- | -------------- | ----- | ----------- | -------- |
|                |           |                    |     |            |              |           |             | of compound | 4              | was inevitable | under | the applied | reaction |
| hydantoin      | 12 and    | 3-(methylsulfonyl) |     |            | benzaldehyde |           | 11 as raw   |             |                |                |       |             |          |
| materials      | to obtain | compound           |     | 1          | (Scheme      | 1b),3     | but this    |             |                |                |       |             |          |
|                |           |                    |     |            |              |           |             | Received:   | October8,      | 2023           |       |             |          |
| method         | involved  | expensive          |     | transition | metal        | catalysts | and         |             |                |                |       |             |          |
|                |           |                    |     |            |              |           |             | Revised:    | January13,2024 |                |       |             |          |
ligands,whicharenotavailableindustrially;thus,itrestrictsthe
application of the method on an industrial scale. Accepted: January29,2024
Inlightoftheaforementionedsetbacks,anenzyme-catalyzed Published: February14, 2024
| hydrolytic                      | resolution | strategy |     | was adopted |               | for the | synthesis of |     |     |     |     |     |     |
| ------------------------------- | ---------- | -------- | --- | ----------- | ------------- | ------- | ------------ | --- | --- | --- | --- | --- | --- |
| 3-(methylsulfonyl)-phenylmethyl |            |          |     | ester       | hydrochloride |         | 1·HCl.       |     |     |     |     |     |     |
©2024AmericanChemicalSociety https://doi.org/10.1021/acs.oprd.3c00358
|     |     |     |     |     |     |     |     | 693 |     |     | Org.ProcessRes.Dev.2024,28,693−703 |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---------------------------------- | --- | --- |

Organic Process Research & Development pubs.acs.org/OPRD Article
Figure 1.Lifitegrastand thekey intermediate.
Scheme 1. Synthetic Route of 1·HCl in the Reported Study
Scheme 2. Retrosynthetic Analysis of N-Acetyl-3-bromo-phenylalanine 6
conditions.Asaresult,atelescopedsynthesiswasimplemented in Scheme 4. Hence, a kit of 32 available EREDs from our
to directly produce compound 5. laboratory was tested. Unfortunately, all of the evaluated
The effect of varying temperature on conversion was EREDs demonstrated unsatisfactory conversion (Table S6 in
studied, and 100 °C was selected as the optimal temperature the Supporting Information).
for this reaction. Subsequently, other parameters were Subsequently, a strategy involving chemical reduction,
investigated. The optimal condition was to use 1.1 equiv of followed by enzymatic resolution, was selected for the
3/0.2equivofAcONaand2.0Vaceticanhydrideassolventin synthesis of compound 7, as shown in Scheme 5.
the reaction. Finally, the described reaction was performed on Initially, sodium borohydride7 was employed to selectively
a 1.0 kg scale with a 78% isolated yield and a purity of 98.2% reduce compound 5 (Table 1, entry 1). Compound 6 did not
(HPLC). form, but impurity 6a was obtained. Different reduction
Optimization of Reduction Reaction (5 to 6). Initially, conditions were investigated to improve the reaction
itwasassumedthat(L)-6couldbeobtainedfrom5via“ene”- selectivity,8−10 but unsatisfactory conversion was observed
reductases(EREDs)-catalyzedasymmetricreduction,asshown (Table 1, entries 2−5).
694 https://doi.org/10.1021/acs.oprd.3c00358
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
| Scheme 3. Syntheses      | of 1 Featuring | Enzyme-Catalyzed | Strategy             |     |     |     |     |
| ------------------------ | -------------- | ---------------- | -------------------- | --- | --- | --- | --- |
| Scheme 4. ERED-Catalyzed | Asymmetric     | Bioreduction     |                      |     |     |     |     |
| Scheme 5. Chemical       | Reduction      | Combined with    | Enzymatic Resolution |     |     |     |     |
conditions.15,16
Subsequently, attempts were made to use Pd/C as catalyst reducing the double bonds of 5 under acidic
and H or HCOONH to reduce11,12 compound 5 (Table 1, After preliminary screening (Table 1, entries 10−11), it was
| 2   | 4   |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
entries6−7).Nonetheless,increasingthereactiontemperature observed that the utilization of HCl resulted in a higher
°C
to 60 did not result in the formation of compound 6. conversion compared to the use of AcOH. As such, a Zn
Instead,adebrominationimpurity,identifiedascompound6b, powder/HCl system was chosen as the reducing agent for the
was generated. The reduction system was changed, and it was subsequent steps. Ultimately, product 6 was obtained with a
found that hydrazine hydrate13 or TsNHNH 14 could 99% isolated yield and 92.1% purity, scaled up to 300.0 g.
2
|                    |                  |             |            | Optimization | of Enzymatic | Resolution | (6 to 7). |
| ------------------ | ---------------- | ----------- | ---------- | ------------ | ------------ | ---------- | --------- |
| selectively reduce | the double bonds | of 5 (Table | 1, entries |              |              |            |           |
8−9), but there was a major problem: incomplete trans- Screening of Acylases for the Hydrolysis of Compound 6.
formation. Finally, Zn powder was found to be capable of ToinvestigatethepotentialofhydrolasesfortheremovalofN-
|     |     |     | 695 |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |
| --- | --- | --- | --- | --- | --- | ---------------------------------------- | --- |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
| Table | 1. Screening | of  | Reduction | Methodsa |     |     |     |     |     |     |     |     |     |
| ----- | ------------ | --- | --------- | -------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
HPLC(%)b
|     | entry |     | reducingagents |     | solvent | 5    |     | 6    |     |      | 6a  |     | 6b   |
| --- | ----- | --- | -------------- | --- | ------- | ---- | --- | ---- | --- | ---- | --- | --- | ---- |
|     | 1     |     | NaBH 4         |     | THF     | 33.5 |     | n.d. |     | 65.5 |     |     | n.d. |
|     | 2     |     | NaBH,NiCl      |     | MeOH    | 97.3 |     | n.d. |     | 1.5  |     |     | n.d. |
|     |       |     | 4              | 2   |         |      |     |      |     |      |     |     |      |
|     | 3     |     | NaBH,CoCl      |     | MeOH    | 83.5 |     | n.d. |     | 1.7  |     |     | n.d. |
|     |       |     | 4              | 2   |         |      |     |      |     |      |     |     |      |
|     | 4     |     | NaBH,CuCl      |     | MeOH    | 46.3 |     | n.d. |     | 50.2 |     |     | n.d. |
4
|     | 5   |     | NaBH(OAc) |     | THF | 98.3 |     | n.d. |     | n.d. |     |     | n.d. |
| --- | --- | --- | --------- | --- | --- | ---- | --- | ---- | --- | ---- | --- | --- | ---- |
3
|     | 6   |     | Pd/C,H 2    |     | EtOH | 88.3 |     | n.d. |     | n.d.  |     |     | 9.1  |
| --- | --- | --- | ----------- | --- | ---- | ---- | --- | ---- | --- | ----- | --- | --- | ---- |
|     | 7   |     | Pd/C,HCOONH |     | MeOH | 98.0 |     | n.d. |     | n.d.. |     |     | n.d. |
4
|     | 8   |     | NH·HO,FeCl |     | EtOH    | 90.2 |     | 7.7 |     | n.d. |     |     | n.d. |
| --- | --- | --- | ---------- | --- | ------- | ---- | --- | --- | --- | ---- | --- | --- | ---- |
|     |     |     | 2 4 2      | 3   |         |      |     |     |     |      |     |     |      |
|     | 9   |     | TsNHNH     |     | dioxane | 90.6 |     | 6.8 |     | n.d. |     |     | n.d. |
2
|     | 10c |     | Zn/AcOH |     | AcOH | 63.4 |     | 23.5 |     | n.d. |     |     | n.d. |
| --- | --- | --- | ------- | --- | ---- | ---- | --- | ---- | --- | ---- | --- | --- | ---- |
11d
|     |     |     | Zn/HCl |     | MeCN | 0.58 |     | 92.1 |     | n.d. |     |     | n.d. |
| --- | --- | --- | ------ | --- | ---- | ---- | --- | ---- | --- | ---- | --- | --- | ---- |
aReaction conditions: 5 (10.0 g scale, 1.0 equiv), 20−25 °C. bMeasured by HPLC. cTemperature of reduction was 75 °C. dTemperature of
| reductionwas | 0°C. |     |     |     |     |     |     |     |     |     |     |     |     |
| ------------ | ---- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
acetyl group, 7 different lipases, acylases, and proteases were recombinant AmACY demonstrated robust enzymatic activity
exploredforthehydrolysisoftheN-acetylprotectinggroup.As toward the substrate N-acetyl-3-bromo-phenylalanine 6,
revealed in previous research, porcine liver lipase can catalyze achieving a maximum conversion of 46.3% and an ee value
hydrolysisofN-acetyl-phenylalanine,17butlipasefromporcine
|     |     |     |     |     |     | of 99.9% | (Table | 2, entry | 6). | This | constitutes | the | inaugural |
| --- | --- | --- | --- | --- | --- | -------- | ------ | -------- | --- | ---- | ----------- | --- | --------- |
liver exhibited no activity when the N-acetyl-3-bromo-phenyl- reportofAmACYbeingemployedintheenzymaticresolution.
alanine 6 was tested (Table 2, entry 1). Further, the ToelucidatetheinteractionbetweenAmACYandsubstrate,
|     |     |     |     |     |     | characterization |     | of AmACY’s |     | dimeric | structure | was | required. |
| --- | --- | --- | --- | --- | --- | ---------------- | --- | ---------- | --- | ------- | --------- | --- | --------- |
Aminoacylasesa
Table 2. Screening of The protein structure of AmACY was simulated using the
|       |        |     |                |        |               | webtool         | SWISS-MODEL                                 |             | with           | the                    | crystal       | structure         | of          |
| ----- | ------ | --- | -------------- | ------ | ------------- | --------------- | ------------------------------------------- | ----------- | -------------- | ---------------------- | ------------- | ----------------- | ----------- |
|       |        |     |                |        |               | acetylornithine |                                             | deacetylase | (PDB           | entry                  | 7RSF)         | from              | E. coli as  |
|       |        |     |                |        |               | a template.     | Taking                                      | into        | account        | the                    | relatively    | low               | level of    |
|       |        |     |                |        |               | sequence        | identity(25.8%)withinthedimerizationdomains |             |                |                        |               |                   | of          |
|       |        |     |                |        |               | AmCY1           | and 7RSF,                                   | we          | also predicted |                        | the protein   | structure         | of          |
|       |        |     |                |        |               | AmACY           | using                                       | AlphaFold2. |                | The                    | final         | three-dimensional |             |
|       |        |     |                |        |               | structure       | of AmACY                                    |             | is shown       | in                     | Figure        | 2A,B.             | The two     |
|       |        |     |                |        |               | simulated       | structures                                  | display     | a              | significant            | structural    |                   | similarity; |
| entry | enzyme |     | conversion(%)c | ee(%)d | configuration |                 |                                             |             |                |                        |               |                   |             |
|       |        |     |                |        |               | however,        | the predictions                             |             | generated      |                        | by AlphaFold2 |                   | for the     |
| 1     | lipase |     | <1             | n.d.   | n.d.          |                 |                                             |             |                |                        |               |                   |             |
|       |        |     |                |        |               | conformations   |                                             | of the      | initial        | 40 amino               | acid          | residues          | were        |
| 2     | papain |     | <1             | n.d.   | n.d.          |                 |                                             |             |                |                        |               |                   |             |
|       |        |     |                |        |               | considered      | unreliable.                                 |             | The model      | obtained               |               | from homology     |             |
| 3     | AsACY  |     | 19.1           | n.d.   | L             |                 |                                             |             |                |                        |               |                   |             |
|       |        |     |                |        |               | modeling        | was used                                    | to dock     | with           | N-acetyl-phenylalanine |               |                   | 6 by        |
| 4     | EcACY  |     | 39.2           | 99.9   | L             |                 |                                             |             |                |                        |               |                   |             |
|       |        |     |                |        |               | means of        | AutoDock.18                                 |             | In this        | simulated              |               | activity          | pocket,     |
| 5b    | GsACY  |     | <1             | n.d.   | n.d.          |                 |                                             |             |                |                        |               |                   |             |
6b AmACY 46.3 99.9 L substrate 6 was docked into the region near the zinc ion.
| 7b  |      |     |     |      |      | Possibleinteractionsbetweenthemodelandsubstrate6within |     |     |     |     |     |     |     |
| --- | ---- | --- | --- | ---- | ---- | ------------------------------------------------------ | --- | --- | --- | --- | --- | --- | --- |
|     | AMID |     | <1  | n.d. | n.d. |                                                        |     |     |     |     |     |     |     |
acontactdistanceof4.0Åwereanalyzed.Thecarbonylgroup
| aReaction | conditions: | 14g/L | 2,  | 0.007 g/L acylase | in 200 mL of |         |         |        |           |     |            |     |          |
| --------- | ----------- | ----- | --- | ----------------- | ------------ | ------- | ------- | ------ | --------- | --- | ---------- | --- | -------- |
|           |             |       |     |                   |              | of E182 | was 2.3 | Å from | substrate | 6   | and formed | a   | hydrogen |
phosphatebuffer(200mM,pH7.0)for24hat40°Candmagnetic
stirring.bReactionconditions:10g/L6,10g/Lwetcellsin2mLof bond with the amine hydrogen of the same substrate. At the
phosphatebuffer(200mM,pH7.2)for24hat30°Cand220rpm. same time, Y345 exhibited the potential to provide hydrogen
cMeasuredbyHPLC.dMeasuredbyaDAICELCR(+)columnwith bonds with the carboxyl groups of substrate 6. Such results
chiralHPLC. suggest that E182 and Y345 are significantly involved in the
|     |     |     |     |     |     | binding | and catalysis |     | of substrates.19 |     | Moreover, | E182 | and |
| --- | --- | --- | --- | --- | --- | ------- | ------------- | --- | ---------------- | --- | --------- | ---- | --- |
commercially available papain and acylases (Table 2, entries Y345 were identified as conserved and functionally critical
2−4)alsoexhibitedlowactivitytowardtheN-acetyl-3-bromo- amino acid residues in multiple protein alignment (Figure 2).
phenylalanine6.ThroughsequencealignmentwiththeN-acyl- Optimization of the Substrate Concentration. In the
aromatic-L-amino acid amidohydrolase data available on the context of industrial production, substrate concentration
GenBank database, two novel acylases were identified, one emerges as the most critical variable and necessitates careful
from Geobacillus stearothermophilus (GsACY) and another consideration.Asubstrateloadinginvestigationwasconducted
from Aspergillus melleus (AmACY). These were subsequently with a concentration range of 15−195 g/L to explore the
expressed in Escherichia coli BL21(DE3). Notably, the catalytic ability. The results reveal that a substrate concen-
|     |     |     |     |     |     | 696 |     |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---------------------------------------- | --- | --- | --- |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
Figure 2. (A) Three-dimensional structure of AmACY predicted using SWISS-MODEL.(B) Three-dimensional structure of AmACYpredicted
usingAlphaFold2. (C)Sequence alignment of7RSF, AmACY,and GsACY. (D)Substratebindingpocket ofAmACY.
tration of up to 120 g/L could be used with no effect on activity of the enzymes decreased. Meanwhile, when the pH
conversion (Figure 3). was above 7.5, the enzyme activity decreased drastically.
|     |     |     |     |     | Hence, the    | optimal    | pH          | was considered |             | to be 7.0−75.    | As          |
| --- | --- | --- | --- | --- | ------------- | ---------- | ----------- | -------------- | ----------- | ---------------- | ----------- |
|     |     |     |     |     | shown in      | Figure     | 4b, the     | optimal        | temperature | for the          | reaction    |
|     |     |     |     |     | system was    | determined | to          | be 40−45       | °C.         |                  |             |
|     |     |     |     |     | During        | the workup | process,    |                | the high    | water solubility | of          |
|     |     |     |     |     | phenylalanine | posed      | significant |                | challenges  | to its           | efficient   |
|     |     |     |     |     | extraction    | from       | the aqueous | medium.        | To          | address          | this issue, |
|     |     |     |     |     | an optimized  | workup     | protocol    | was            | devised,    | substantiated    | by          |
|     |     |     |     |     | empirical     | data, as   | shown       | in Figure      | 5. The      | pH of the        | aqueous     |
phasewasinitiallyadjustedtoarangeof3−4using1.0MHCl.
Subsequently,THFwasemployedtocompletelyextract(D)-6
|     |     |     |     |     | through | a tripartite | extraction |     | procedure. | The pH | of the |
| --- | --- | --- | --- | --- | ------- | ------------ | ---------- | --- | ---------- | ------ | ------ |
aqueousphasewasthenadjustedtoarangeof9−10,followed
Figure3.Effectofthesubstrateconcentrationonthehydrolysisof6.
Reaction conditions: various concentrations of substrate 6, 10 g/L by the addition of Boc O to facilitate the formation of
2
wetcells,phosphatebuffer(200mM,pH7.0)ina100mLreaction compound 8. Ultimately, compound 8 was obtained with an
hat40°Cand
systemfor24 magneticstirring. isolatedyieldof40%overthreestepsandapurityof99.6%on
|              |                   |                  |                |     | a 300.0 g | scale. |              |         |                |             |         |
| ------------ | ----------------- | ---------------- | -------------- | --- | --------- | ------ | ------------ | ------- | -------------- | ----------- | ------- |
|              |                   |                  |                |     | Recycling | of     | the Unwanted |         | (D)-6          | Enantiomer. | The     |
| Optimization | of pH             | and Temperature. | The pH         | and |           |        |              |         |                |             |         |
|              |                   |                  | activity.20−22 |     | unwanted  | (D)-6  | isomer       | lost in | the resolution | mother      | liquors |
| temperature  | greatly influence | the enzymatic    |                | In  |           |        |              |         |                |             |         |
the present study, a pH tolerance investigation of acylase was not only lowered the total yield but also generated substantial
performedinthepHrangeof5.5−8.5(Figure4a).Theresults waste. However, the defects could be effectively mitigated if a
demonstrate that when the pH was below 7, the catalytic method was developed to recycle the (D)-6 isomer back into
Figure4.(a)EffectofthepHonhydrolysis.Reactionconditions:thereactionswereperformedwith15g/L6,0.007g/Lacylaseina100mL
reactionsystemfor24hat40°CandmagneticstirringindifferentpHbuffersolutions.(b)Effectofthetemperatureonthehydrolysissystem.
Reactionconditions:thetemperatureinvestigationwasperformedwith15g/L6,0.007g/Lacylase,andphosphatebuffer(200mM,pH7.0)ina
| 100mL reaction | systemfor | 24hatmagneticstirring. |     |     |     |     |     |     |                                          |     |     |
| -------------- | --------- | ---------------------- | --- | --- | --- | --- | --- | --- | ---------------------------------------- | --- | --- |
|                |           |                        |     |     | 697 |     |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |     |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
| Figure 5.Optimization | ofthe | workupprocess. |     |     |     |     |     |     |     |     |     |     |     |
| --------------------- | ----- | -------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
(rac)-6.Thus,therecyclingoftheunwanted(D)-6enantiomer obtain the corresponding mixed anhydride (D)-6m. Then,
from the resolution mother liquors was explored. mixed anhydride (D)-6m produced racemic mixed anhydride
Initialattemptstocatalyzetheracemizationprocessinvolved (rac)-6m via keto−enol tautomerism, which could react with
using strong basic conditions. However, such conditions were anothermoleculeof(D)-6toform(rac)-6andreproduce(D)-
| insufficient | to produce | a racemic | mixture | of (D)-6/(L)-6 |     | 6m. |     |     |     |     |     |     |     |
| ------------ | ---------- | --------- | ------- | -------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
1−4).
(Table 3, entries Previous studies have indicated that The optimized racemization procedure was as follows: the
|     |     |     |     |     |     | (D)-6wastreatedwithequivalentAc |     |     |     | OinAcOHat90°Cfor |     |     |     |
| --- | --- | --- | --- | --- | --- | ------------------------------- | --- | --- | --- | ---------------- | --- | --- | --- |
2
Table 3. Optimization for the (D)-6 Racemization 8 h with 48% yield (maximum theoretical yield: 50%). This
|       |                 |       |      |                 |     | streamlined                   | and           | cost-effective                       |               | racemization |            | strategy        | holds |
| ----- | --------------- | ----- | ---- | --------------- | --- | ----------------------------- | ------------- | ------------------------------------ | ------------- | ------------ | ---------- | --------------- | ----- |
|       |                 |       |      |                 |     | industrial                    | relevance,    | offering                             | a             | feasible     | method     | for recycling   |       |
|       |                 |       |      |                 |     | waste (D)-6                   | to obtain     |                                      | (rac)-6.      |              |            |                 |       |
|       |                 |       |      |                 |     | Absolute                      | configuration |                                      | was           | assigned     | as         | (L) by          | X-ray |
|       |                 |       |      |                 |     | diffraction                   | of the        | dicyclo                              | hexylamine    |              | salt of    | 8, as shown     | in    |
|       |                 |       |      |                 |     | Figure 6.                     |               |                                      |               |              |            |                 |       |
|       |                 |       |      |                 |     | According                     | to            | the literature,2                     |               | product      | 9 was      | prepared        | by    |
|       |                 |       |      | (D)-6/(L)-6(%)e |     | methylsulfonation             |               | of compound                          |               | 8, followed  |            | by benzylester- |       |
| entry | additive(equiv) | T(°C) | t(h) |                 |     |                               |               |                                      |               |              |            |                 |       |
|       |                 |       |      |                 |     | ification                     | to obtain     | N-[(1,1-dimethylethoxy)-carbonyl]-3- |               |              |            |                 |       |
| 1a    | NaOH(1.0)       | 100   | 10   | 95.3/4.7        |     |                               |               |                                      |               |              |            |                 |       |
|       |                 |       |      |                 |     | (methylsulfonyl)-phenylmethyl |               |                                      |               | ester 10.    |            |                 |       |
| 2a    | NaOH(2.0)       | 100   | 10   | 96.1/3.9        |     |                               |               |                                      |               |              |            |                 |       |
|       |                 |       |      |                 |     | Optimization                  |               | of                                   | Deprotection. |              | In Zhong’s | research,       |       |
3b
EtONa(1.0) 70 10 93.5/6.5 deprotectionwasconductedusingHCl1,4-dioxanesolutionin
4c
MeONa(1.0) 60 10 97.6/2.4 DCM,2butthereactionconversionwasonly1.2%afterheating
| 5d  | AcO(1.0) | 90  |     | 6 56.8/43.2 |     |     |     |     |     |     |     |     |     |
| --- | -------- | --- | --- | ----------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
2 for 8 h (Table 4, entry 1). Subsequent efforts to switch the
| 6d                                           | AcO(1.0) | 90  |     | 8 50.1/49.9 |     |                                                          |     |     |             |        |     |         |       |
| -------------------------------------------- | -------- | --- | --- | ----------- | --- | -------------------------------------------------------- | --- | --- | ----------- | ------ | --- | ------- | ----- |
|                                              | 2        |     |     |             |     | hydrogenchloridesolutionwhileretainingtheoriginalsolvent |     |     |             |        |     |         |       |
| aReactionconditions:0.1g/mL(D)-6(90.6%ee)inH |          |     |     | O.bReaction |     |                                                          |     |     |             |        |     |         |       |
|                                              |          |     |     | 2           |     | also resulted                                            | in  | low | conversions | (Table | 4,  | entries | 2−5). |
cReaction
conditions: 0.1 g/mL (D)-6 (92.2% ee) in EtOH. Alternative solvents were then explored to address this issue.
dReaction
| conditions: | 0.1 g/mL (D)-6 | (87.0%      | ee)    | in MeOH.  |      |               |        |            |             |            |         |               |          |
| ----------- | -------------- | ----------- | ------ | --------- | ---- | ------------- | ------ | ---------- | ----------- | ---------- | ------- | ------------- | -------- |
|             |                |             |        | eMeasured |      | Initially,    | EA was | used       | for the     | subsequent |         | investigation | of       |
| conditions: | 0.1 g/mL (D)-6 | (95.2%      | ee) in | AcOH.     | by a |               |        |            |             |            |         |               |          |
|             |                |             |        |           |      | deprotection. | With   | the        | use of HCl  | ethyl      | acetate | solution,     | the      |
| DAICELIC    | columnwith     | chiralHPLC. |        |           |      |               |        |            |             |            |         |               |          |
|             |                |             |        |           |      | conversion    | was    | only 23.3% | (Table      | 4,         | entry   | 6). Notably,  | the      |
|             |                |             |        |           |      | application   | of a   | HCl        | isopropanol | solution   |         | in this       | reaction |
oxazolone (also known as azlactone) formation is a likely increased the conversion to 96.3% (Table 4, entry 7). When
pathway for racemization, particularly when the acid alcohols were employed as solvents, elevated conversion was
acid.23
component is a protected amino This suggests that observed, but the resultant crude 1·HCl failed to precipitate
oxazolone formation is a critical mechanism to consider for from the reaction mixture, necessitating additional postpro-
achieving racemization. During the synthesis of compound 5, cessingsteps(Table4,entries8−10).Oilycrude1·HClcould
anoxazoloneintermediatewasalsoformed.Thissuggeststhat be obtained if THF or 1,4-dioxane were used as solvents
11−12).
(D)-6 could be converted back to a racemic mixture (rac)-6 (Table 4, entries Finally, the reaction was conducted
via oxazolone (or azlactone) formation under AcOH/Ac O according to the conditions in entry 7.
2
conditions. Nevertheless, it was observed that a reaction time Refinement of the Key Intermediate (1·HCl). Crude 1·
of6hwasinsufficienttoyieldaracemicmixtureof(D)-6/(L)- HCl was obtained by following Zhong’s research.2 However,
6(Table3,entry5).Uponextendingthereactiontimeto8h, Zhong did not clarify the details regarding recrystallization.
a near-equimolar racemic mixture of (D)-6/(L)-6 with a ratio Thus, a solubility experiment was conducted to identify a
of 50.1:49.9 was successfully achieved (Table 3, entry 6). The suitable recrystallization solvent. The solubility profile
recycled (rac)-6 was tried to subject back to the enzymatic indicated the following solvent hierarchy: Formamide >
resolution reaction, and this process afforded (L)-7 in 59.5% DMF > MeOH, EtOH > i-PrOH > acetone > EA > MBE >
(40.0%withoutrecycling)yieldwithtwotimesrecyclingofthe DCM > 1,4-dioxane.
unwanted (D)-6. According to the purification method in Zhong’s research,
recrystallizationwasperformedusingDMFandDCM,2butthe
Thepossiblemechanismofracemizationcouldbedescribed,
as shown in Scheme 6. First, (D)-6 reacted with Ac O to yieldof1·HClwasjust35%(Table5,entries1−5).Theyield
2
|     |     |     |     |     |     | 698 |     |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---------------------------------------- | --- | --- | --- |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
| Scheme 6. Possible      | Pathway             | for Racemization |     |     |     |     |
| ----------------------- | ------------------- | ---------------- | --- | --- | --- | --- |
| Figure 6.Single-crystal | X-raydiffractionand | structure of8·Cy | NH. |     |     |     |
2
| Table 4. Optimization | of Deprotectiona |     |     |     |     |     |
| --------------------- | ---------------- | --- | --- | --- | --- | --- |
entry solvent HClsolution(4.0M) equivalents(eq) time(h) conversion(%)b
| 1                        | DCM               | 1,4-dioxane |     | 4   | 8                                        | 1.2  |
| ------------------------ | ----------------- | ----------- | --- | --- | ---------------------------------------- | ---- |
| 2                        | DCM               | EA          |     | 4   | 8                                        | 6.4  |
| 3                        | DCM               | i-PrOH      |     | 4   | 8                                        | 11.1 |
| 4                        | DCM               | EtOH        |     | 4   | 8                                        | 13.7 |
| 5                        | DCM               | MeOH        |     | 4   | 8                                        | 15.3 |
| 6                        | EA                | EA          |     | 4   | 8                                        | 23.3 |
| 7                        | EA                | i-PrOH      |     | 4   | 8                                        | 96.3 |
| 8                        | i-PrOH            | i-PrOH      |     | 4   | 8                                        | 98.6 |
| 9                        | MeOH              | MeOH        |     | 4   | 8                                        | 97.3 |
| 10                       | EtOH              | EtOH        |     | 4   | 8                                        | 98.6 |
| 11                       | THF               | con.HCl     |     | 4   | 8                                        | 99.3 |
| 12                       | 1,4-dioxane       | 1,4-dioxane |     | 4   | 8                                        | 96.2 |
| aReaction conditions:10g | scale.bMeasuredby | HPLC.       |     |     |                                          |      |
|                          |                   |             | 699 |     | https://doi.org/10.1021/acs.oprd.3c00358 |      |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
| Table     | 5. Optimization | of Recrystallization |         | Solvent for        | the 1·HCla |              |           |     |          |           |            |     |
| --------- | --------------- | -------------------- | ------- | ------------------ | ---------- | ------------ | --------- | --- | -------- | --------- | ---------- | --- |
|           | entry           | solvent              |         | ratios             |            | volumes(V)   |           |     |          | yield(%)b | purity(%)c |     |
|           | 1               | DCM/DMF              |         | 9:1                |            |              | 5         |     |          |           |            |     |
|           | 2               | DCM/DMF              |         | 9:1                |            |              | 10        |     |          |           |            |     |
|           | 3               | DCM/DMF              |         | 4:1                |            |              | 5         |     |          |           |            |     |
|           | 4               | DCM/DMF              |         | 4:1                |            |              | 10        |     |          |           |            |     |
|           | 5               | DCM/DMF              |         | 1:1                |            |              | 5         |     |          | 35        | 98.7       |     |
|           | 6               | EA/MeOH              |         | 4:1                |            |              | 5         |     |          |           |            |     |
|           | 7               | EA/MeOH              |         | 4:1                |            |              | 5         |     |          |           |            |     |
|           | 8               | EA/MeOH              |         | 3:2                |            |              | 5         |     |          | 53        | 99.5       |     |
|           | 9               | EA/IPA               |         | 9:1                |            |              | 5         |     |          |           |            |     |
|           | 10              | EA/IPA               |         | 4:1                |            |              | 5         |     |          | 75        | 99.7       |     |
| aReaction |                 | gscale.bThe          |         |                    |            |              | cMeasured |     |          |           |            |     |
|           | conditions:3.0  |                      | yieldis | from8 to 1·HClover |            | three steps. |           |     | by HPLC. |           |            |     |
and purity of 1·HCl could reach 53 and 99.5% by using EA/ onaDionexUItiMate3000chromatographsystemwithaUV
MeOHassolvent(Table5,entries6−8).24 Finally,theresults detector. (Method 1): The procedures for preparing the
showthatEA/IPAwastheoptimalrecrystallizationsystemfor diluent for compounds 5, 8, 9, and 10 involved the use of a
obtaining1·HCl(Table5,entries9−10).Notably,1·HClhad
|     |     |     |     |     |     | NanoChrom |     | chromCore120 |     | C18columnwith | dimensionsof |     |
| --- | --- | --- | --- | --- | --- | --------- | --- | ------------ | --- | ------------- | ------------ | --- |
anisolatedyieldof75%overthreestepsandapurityof99.7% 150 mm × 4.6 mm and a particle size of 3 μm. The column
on a 150.0 g scale. was maintained at a temperature of 30 °C. The flow rate was
| ■   |     |     |     |     |     | set | at 1 | mL/min, | and | a UV detector | was used | with a |
| --- | --- | --- | --- | --- | --- | --- | ---- | ------- | --- | ------------- | -------- | ------ |
CONCLUSIONS wavelength (λ) set at 200 nm. The analysis duration was 15
Insummary,anewchemoenzymaticprocesswasdesignedand min. Solvent A consisted of 0.1% formic acid in water. A
developed for preparing a key intermediate of Lifitegrast, 3- gradient elution program was employed with the time (in
(methylsulfonyl)-L-phenylalaninephenylmethylester1.First,a minutes)andpercentageofsolventAasfollows:0/95,10/10,
processforefficientlyconstructingacetylaminocinnamicacid5 12/95, and 15/95. Solvent B used was acetonitrile (CH CN).
3
from inexpensive and commercially available 3-bromobenzal- (Method 2): The procedures for preparing the diluent for
dehyde 2 was proposed and optimized. The yield of the two compounds 6, 7·HCl, and 1·HCl were as follows: A Waters
steps was 80%, and the purity of the product reached up to SPHERISORB ODS1 column with dimensions of 250 mm ×
97.6%.Second,aselectivereductionprocesswasdevelopedfor 4.6 mm and a particle size of 5 μm was maintained at a
obtainingN-Ac-phenylalanineintermediate6,andasimpleand temperatureof30°C.Theflowratewassetat1mL/min.UV
(λ)
enzymatic hydrolysis system was identified for obtaining 3- detection was performed at a wavelength of 214 nm, and
bromo-N-Boc-L-phenylalanine 8 with a 40% yield, 99.5% theanalysishadadurationof60min.SolventAwascomposed
purity, and 99.9% ee in three steps. Finally, 1·HCl was of 0.1% phosphoric acid in water. A gradient elution program
obtained via the introduction of methylsulfonyl, benzyl ester was applied with time (in minutes) and percentage of solvent
protection,andBoc-deprotectionwith75%yield,99.7%purity, Aasfollows:0/85,25/80,30/75,35/70,and60/65.SolventB
and99.9%eeinthreesteps.Theyieldoftheoverall8stepsin was CH CN. (Method 3): For chiral HPLC analysis of
3
this new route reached up to 23.4% with 99.7% purity and compound 7, a DAICEL CROWNPAK CR (+) column with
99.9%ee.Thisnovelchemoenzymaticprocesswasfoundtobe dimensions of 4.0 mm × 150 mm and a particle size of 5 μm
both cost-effective and eco-friendly, making it suitable for was used. The mobile phase consisted of 0.1% trifluoroacetic
industrial applications.
|     |     |     |     |     |     | acid | (TFA) | in water | (V/V), | employing | isocratic elution. | The |
| --- | --- | --- | --- | --- | --- | ---- | ----- | -------- | ------ | --------- | ------------------ | --- |
■
|     |              |         |     |     |     | UV        | detection | was   | conducted   | at a wavelength | of 200 nm.     | The |
| --- | ------------ | ------- | --- | --- | --- | --------- | --------- | ----- | ----------- | --------------- | -------------- | --- |
|     | EXPERIMENTAL | SECTION |     |     |     |           |           |       |             |                 |                |     |
|     |              |         |     |     |     | retention |           | times | were 27.104 | min for the     | (R) enantiomer | and |
General Methods. Solvent and reagents obtained from 38.654 min for the (S) enantiomer. (Method 4): For chiral
|            |         |           |         |                       |     | HPLC | of  | compound |     | 1·HCl, a DAICEL | CHIRALPAK | IF  |
| ---------- | ------- | --------- | ------- | --------------------- | --- | ---- | --- | -------- | --- | --------------- | --------- | --- |
| commercial | sources | were used | without | further purification, |     |      |     |          |     |                 |           |     |
unless otherwise noted. 1H and 13C NMR spectra were column with dimensions of 4.6 mm × 250 mm and a particle
recorded on a Bruker 400 MHz instrument with tetramethyl size of 5 μm was used. The mobile phase was 30% ethanol
silaneasaninternalstandard.Datafor1HNMRarepresented (EtOH) in n-hexane (v/v) under isocratic elution conditions.
in terms of chemical shift values in parts per million (ppm), UV detection was at a wavelength of 220 nm. The retention
andmultiplicitiesaredenotedasfollows:s,singlet;d,doublet; timeswere27.563minforthe(S)enantiomerand34.182min
t,triplet;q,quartet;m,multiplet;br,broad.Datafor13CNMR for the (R) enantiomer.
are reported as a chemical shift. High-resolution mass Cloning and Expression. The codon-optimized genes of
spectrometry (HRMS) spectra were recorded using a Waters AmACY (accession number XP_045938252.1) and GsACY
quadrupole time-of-flight (Q-TOF) micromass spectrometer (accession number P37112.1) were synthesized and cloned
with an electrospray ionization (ESI) source. Single-crystal X- into a pET-22b(+) vector using the TOROIVD One Step
ray diffraction (SCXRD) data were recorded on a Bruker D8 Fusion Cloning Mix. All plasmids were transformed to E. coli
Venture. The purity was determined by using HPLC analysis BL21 (DE3) cells for expression. The transformed cells were
|     |     |     |     |     |     | 700 |     |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---------------------------------------- | --- | --- |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
culturedat37°Cfor14hin50mLofLBmediumcontaining acquiredat100MHzinDMSO-d ,displayedchemicalshiftsat
6
50 μg/mL ampicillin. The preculture was inoculated into the δ 173.32, 169.74, 141.05, 132.30, 130.74, 129.77, 128.67,
jarfermenterwith3Loffermentationmediumandculturedat 121.85, 53.67, 36.69, and 22.75. High-resolution mass
37 °C. When OD reached a value of 2, 1 mM IPTG was spectrometry (HRMS) using ESI-QTOF revealed a m/z
600
added into the fermentation medium, and cultivation was value calculated for C H BrNO [M + H]+ of 286.00733,
11 12 3
continued at 28 °C overnight. The composition of the and the observed value was 286.00614.
fermentation medium was as follows (w/v): 24 g/L yeast 3-Bromo-L-phenylalanine (7). First, 2.8 L of phosphate
extract,12g/Ltryptone,3g/LNaCl,2g/LK HPO ,0.5g/L buffer(0.5M)wasaddedtoa10.0Lfour-neckflask,followed
2 4
MgSO ·7H O, and 30 g/L glycerol. The cells were then by mechanical stirring at 350 rpm. Then, N-acetyl-3-bromo-
4 2
harvested by means of centrifugation (6000g, 4 °C, 30 min) phenylalanine (6) (from the previous step) was added. The
and stored at −20 °C. reactionvesselwasplacedina40°Cwaterbath.Thesolution
AsACY was purchased from Shanghai Aladdin Biochemical pH was adjusted to 7.0−7.5 using 10% NaOH water solution,
Technology Co., Ltd.; EcACY was purchased from Shanghai followed by the addition of 280.0 g of AmACY wet cells.
Macklin Biochemical Technology Co., Ltd.; Papain was During the reaction, the pH value was closely monitored by
purchased from Shanghai Titan Technology Co., Ltd.; and usingapHmeter.A10%NaOHsolutionwasaddeddropwise
Lipase was purchased from Beijing Hwrkchemical Co., Ltd. (slowly) to maintain a pH level between 7.0 and 7.5. The
2-(Acetylamino)-3-(3-bromophenyl)-2-propenoicAcid(5). resulting slurry was stirred at ambient temperature for 24 h.
In a reaction setup, 3-bromobenzaldehyde (2) (1.0 kg, 5.40 HPLCanalysisshowedthattheproductcontentwas43−46%,
mol)andN-acetyl-glycine(3)(696.2g,5.95mol)wereadded at which point the reaction was terminated. The pH was
to Ac O (2.0 L) in one portion to form a clear solution, to adjusted to3.5; themixturewasextractedwithTHF (0.5L ×
2
which sodium acetate (88.7 g, 1.08 mol) was added, and the 3)andtheorganiclayerwaswashedwithsaturatedNaCl(200
mixturewasstirredoveraperiodof8hat105°C.Thecolorof mL × 2). The aqueous layers were combined and used in the
the solution changed from colorless to black. The progress of subsequentreactionwithoutfurtherpurification.The1HNMR
the reaction was monitored using HPLC. After the reaction spectrum of the compound, recorded at 600 MHz in DMSO-
was complete, the reaction solution was cooled to 10 °C and d , exhibited resonances at δ 8.65 (s, 3H), δ 7.53 (d, J = 1.5
6
filtered. The filtrate was added to water (5.0 L) and then Hz, 1H), δ 7.49−7.44 (m, 1H), δ 7.30 (dt, J = 15.4, 7.7 Hz,
stirredfor12hatatemperatureof75−85°C.Themixturewas 2H),δ4.14(t,J=6.2Hz,1H),andδ3.19(d,J=6.4Hz,2H).
then cooled to 0 °C, and the resulting solids were filtered, The 13C NMR spectrum, taken at 100 MHz in DMSO-d ,
6
washed with water, and dried at 65 °C. Compound 5 was showed chemical shifts at δ 170.49, 138.46, 132.75, 131.06,
isolatedintheformofayellow,powderedsolidwith78%yield 130.51,129.24,122.18,53.40,and35.40.High-resolutionmass
(1.2 kg) and an HPLC purity of 98.2%. The spectroscopic spectrometry (HRMS) using an ESI-QTOF technique
characteristics of the compound were analyzed using 1H and revealed an m/z value calculated for C H BrNO [M + H]+
9 10 2
13C NMR. The 1H NMR spectrum, recorded at 400 MHz in as 243.99677, and the value found was 243.99568.
DMSO-d , exhibited peaks at δ 9.49 (s, 1H), 7.62 (d, J = 7.2 3-Bromo-N-[(1,1-dimethylethoxy)carbonyl]-L-phenylala-
6
Hz,2H),7.38(dt,J=21.5,7.1Hz,3H),7.24(s,1H),and2.00 nine 8. NaOH (40.0 g, 1.00 mol) was added to the aqueous
(s,3H).The13CNMRspectrum,obtainedat100MHzalsoin layerofcompound7(fromthepreviousstep)toadjustthepH
DMSO-d , showed resonances at δ 169.59, 166.60, 136.71, to9.0,followedbytheadditionofBoc O(109.0g,0.50mol).
6 2
132.33, 132.02, 131.05, 129.43, 129.06, 129.01, 122.22, and Afterthereactionreachedcompletion,asconfirmedbyHPLC
22.96.High-resolutionmassspectrometry(HRMS)usingESI- monitoring, EtOAc was added to the reaction mixture. The
QTOFindicateda m/zvaluecalculatedforC H BrNO [M solution was agitated, allowing for phase separation. The
11 10 3
+ H]+ as 283.99168, with an observed value of 283.99029. aqueous layer was then separated from the organic layer.
N-Acetyl-3-bromo-phenylalanine (6). A suspension of 2- Subsequent extractions of the aqueous layer were performed
(acetylamino)-3-(3-bromophenyl)-2-propenoic acid (5) by using additional portions of EtOAc to ensure maximal
(283.0 g, 1.00 mol) was prepared in MeCN (1.4 L), and the product recovery. The organic layers were combined and
resulting mixture was cooled to 0 °C, to which Zn powder concentrated, and n-hexane was added. The precipitated solid
(130.8 g, 2.00 mol) was added. Subsequently, concentrated was filtered and washed with n-hexane to obtain compound 8
HCl (0.5 L, 6.00 mol) was added dropwise at 0 °C. The (137.2 g, 0.40 mol) as a white solid, and the typical yield was
resulting slurry was stirred at 0 °C. The reaction was 40% over three steps with a purity of 99.6% and ee value of
monitored using HPLC and terminated after 8 h when the 99.9%. The compound was characterized by using various
N-acetyl-3-bromo-phenylalanine 6 content was 90−95%. The analytical techniques. 1H NMR (400 MHz, DMSO-d )
6
solvent was concentrated under reduced pressure, and 2- revealed peaks at δ 7.46 (s, 1H), 7.40 (d, J = 7.0 Hz, 1H),
methyltetrahydrofuran (1.4 L) was added to form a clear 7.26(d,J=13.7Hz,2H),7.11(d,J=8.5Hz,1H),4.12(dd,J
solution. The organic phase was washed with saturated =10.7,8.2Hz,1H),3.05(dd,J=13.7,4.3Hz,1H),2.82(dd,
ammonium chloride solution (300 mL × 3). The aqueous J=13.6,10.7Hz,1H),and1.33(s,9H).The13CNMR(100
phase was extracted with 2-methyltetrahydrofuran (200 mL × MHz, DMSO-d ) showed peaks at δ 173.73, 155.83, 141.41,
6
3). The combined organic phase was evaporated under high 132.35, 130.68, 129.62, 128.69, 121.80, 78.53, 55.24, 36.44,
vacuum to obtain a pale-yellow solid, which was used directly and 28.57. High-resolution mass spectrometry (ESI-QTOF)
in the next step without any purification. The compound’s 1H gave a m/z calculated for C H BrNO [M + Na]+ of
14 18 4
NMR spectrum, obtained at 400 MHz in DMSO-d , featured 366.03114, and a found value of 366.02947.
6
resonances at δ 8.24 (d, J = 8.1 Hz, 1H), δ 7.43 (d, J = 16.5 Racemization of (D)-6. The resolution mother liquor
Hz,2H),δ7.25(d,J=4.9Hz,2H),δ4.42(td,J=9.4,4.9Hz, enriched with (D)-6 was distilled under reduced pressure to
1H),δ3.06(dd,J=13.8,4.9Hz,1H),δ2.84(dd,J=13.8,9.7 remove THF, and (D)-6 was obtained as a brown oil. A
Hz, 1H), and δ 1.79 (s, 3H). The 13C NMR spectrum, solutionofenriched(D)-6(141.5g,0.5mol)inAcOH(425.0
701 https://doi.org/10.1021/acs.oprd.3c00358
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
mL) was stirred with Ac O (5.1 g, 0.05 mol) at 90 °C. The and then washed with EtOAc (45 mL) to afford the crude
2
racemization process was monitored using chiral HPLC product,whichwasrecrystallizedfromIPA/EtOActoproduce
analysis. After (D)-6 was found to be fully racemized, H O 1·HCl 1·HCl
|     |     |     |     |     |     | 2   | the | as a | white solid. | A   | total of | 138.6 g | of was |
| --- | --- | --- | --- | --- | --- | --- | --- | ---- | ------------ | --- | -------- | ------- | ------ |
(500.0mL)wasaddedtothemixture.Afterbeingstirredfor2 obtained with a yield of 75% over three steps, chemical purity
h at 90 °C, the reaction mixture was extracted with isopropyl of 99.7%, and an ee value of 99.9%. 1H NMR (400 MHz,
acetate (3 × 500 mL). Subsequently, the organic layer was DMSO-d )revealedpeaksatδ8.98(s,3H),7.92(s,1H),7.83
6
washed twice with a saturated NaCl aqueous solution. (dt, J = 6.7, 1.9 Hz, 1H), 7.61−7.51 (m, 2H), 7.41−7.32 (m,
Subsequently, the combined extracts of compound 6 were 3H),7.27(dd,J=7.0,2.5Hz,2H),5.15(q,J=12.4Hz,2H),
evaporated to 500 mL, and then dicyclo hexylamine (90.5 g, 4.45(dd,J=7.5,6.0Hz,1H),3.41(dd,J=14.0,5.8Hz,1H),
0.5 mol) was added to induce precipitation. The precipitate 3.29 (dd, J = 14.1, 7.7 Hz, 1H), and 3.17 (s, 3H). The 13C
wasfilteredandthenwashedwithisopropylacetate(100mL) NMR (100 MHz, DMSO-d ) showed peaks at δ 169.12,
6
| to yield (rac)-6·Cy |     | NH as | a white | solid (221.4 | g;  | yield 95%; |                                                          |     |     |     |     |     |     |
| ------------------- | --- | ----- | ------- | ------------ | --- | ---------- | -------------------------------------------------------- | --- | --- | --- | --- | --- | --- |
|                     |     | 2     |         |              |     |            | 141.46,136.98,135.25,135.13,130.07,128.88,128.79,128.64, |     |     |     |     |     |     |
HPLC purity, 99.8%). 128.41,126.21,67.55,53.33,43.99,and35.81.High-resolution
Dissociation of (rac)-6·Cy NH. The pH of a suspension of mass spectrometry (ESI-QTOF) gave an m/z calculated for
2
the enriched (rac)-6·Cy NH (221.4 g, 0.48 mol) in H O (1.1 C17H19NO4S [M + H]+ of 334.11076, and a found value of
|     |     | 2   |     |     |     | 2   |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
L)wasadjustedto10.0with10%NaOHaqueoussolutionand
334.10928.
| stirred for | 2 h. Then, | the resulting |     | mixture | was extracted | with |     |     |     |     |     |     |     |
| ----------- | ---------- | ------------- | --- | ------- | ------------- | ---- | --- | --- | --- | --- | --- | --- | --- |
■
×
n-hexane (3 100 mL). The aqueous phase could be used ASSOCIATED CONTENT
| directly for | the acylase | hydrolysis |     | resolution. |     |     |     |     |     |     |     |     |     |
| ------------ | ----------- | ---------- | --- | ----------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
*
N-[(1,1-Dimethylethoxy)carbonyl]-3-(methylsulfonyl)-L- sı Supporting Information
phenylalanine 9. First, 3-bromo-N-[(1,1-dimethylethoxy)- The Supporting Information is available free of charge at
| carbonyl]-L-phenylalanine |     |     | (8) (172.0 | g, 0.50 | mol) | was added |     |     |     |     |     |     |     |
| ------------------------- | --- | --- | ---------- | ------- | ---- | --------- | --- | --- | --- | --- | --- | --- | --- |
https://pubs.acs.org/doi/10.1021/acs.oprd.3c00358.
toa1.0Lfour-neckflask.Then,860mLofDMSOwasadded,
|          |               |     |           |               |     |        |     | HPLC spectra | for | compounds |     | 5, 6, 7·HCl, | 8, and 1· |
| -------- | ------------- | --- | --------- | ------------- | --- | ------ | --- | ------------ | --- | --------- | --- | ------------ | --------- |
| followed | by mechanical |     | stirring. | Subsequently, |     | sodium |     |              |     |           |     |              |           |
HCl;NMRspectraforcompounds5,6,7·HCl,8,and1·
| methanesulfinate | (66.0 | g,  | 0.65 mol), | cuprous | iodide | (114.0 |     |     |     |     |     |     |     |
| ---------------- | ----- | --- | ---------- | ------- | ------ | ------ | --- | --- | --- | --- | --- | --- | --- |
g, 0.60 mol), L-(−)-proline (79.0 g, 0.60 mol), and potassium HCl;HRMSspectraforcompounds5,6,7·HCl,8,and
carbonate (34.5 g, 0.25 mol) were sequentially charged into a 1·HCl; and SCXRD data for 8·Cy NH (PDF)
2
| four-necked         | flask | under N                       | . The | reaction | mixture   | was then    |        |     |             |     |     |     |     |
| ------------------- | ----- | ----------------------------- | ----- | -------- | --------- | ----------- | ------ | --- | ----------- | --- | --- | --- | --- |
|                     |       |                               | 2     |          |           |             | ■      |     |             |     |     |     |     |
| agitatedat100°Cfor8 |       | h.Oncetheconversionofcompound |       |          |           |             |        |     |             |     |     |     |     |
|                     |       |                               |       |          |           |             | AUTHOR |     | INFORMATION |     |     |     |     |
| 8 was complete      | as    | determined                    | by    | HPLC     | analysis, | the mixture |        |     |             |     |     |     |     |
wasgraduallycooledto0−5°C,followedbydropwiseaddition Corresponding Authors
ofcitricacidaqueoussolution(10%)toadjustthepHto3−4.
|     |     |     |     |     |     |     | Chuanmeng |     | Zhao − | Shanghai | Institute | of Pharmaceutical |     |
| --- | --- | --- | --- | --- | --- | --- | --------- | --- | ------ | -------- | --------- | ----------------- | --- |
The precipitated solid was discarded via filtration, and the Industry, China State Institute of Pharmaceutical Industry,
mother liquid was extracted by means of DCM. The organic 201203 Shanghai, China; orcid.org/0000-0002-1215-
layerswerecombined,washedwithwater,andconcentratedto
|            |               |     |       |         |       |            | 8927; | Email:  | hotcmeng@163.com |           |                   |     |           |
| ---------- | ------------- | --- | ----- | ------- | ----- | ---------- | ----- | ------- | ---------------- | --------- | ----------------- | --- | --------- |
| producethe | crudeproduct, |     | which | wasused | inthe | subsequent |       |         |                  |           |                   |     |           |
|            |               |     |       |         |       |            | Fuli  | Zhang − | Shanghai         | Institute | of Pharmaceutical |     | Industry, |
reaction without further purification. China State Institute of Pharmaceutical Industry, 201203
N-[(1,1-Dimethylethoxy)carbonyl]-3-(methylsulfonyl)- Shanghai, China; orcid.org/0000-0002-4175-4795;
phenylmethyl Ester 10. Compound 9 (from the previous Email: zhangfuli1@sinopharm.com
| step) was   | dissolved | with        | dichloromethane |              | (1.7 | L) and   |           |       | −        |           |                   |                   |           |
| ----------- | --------- | ----------- | --------------- | ------------ | ---- | -------- | --------- | ----- | -------- | --------- | ----------------- | ----------------- | --------- |
|             |           |             |                 |              |      |          | Shaoxin   | Chen  | Shanghai | Institute |                   | of Pharmaceutical |           |
| transferred | to a 3.0  | L four-neck |                 | flask. Then, | DMAP | (12.0 g, |           |       |          |           |                   |                   |           |
|             |           |             |                 |              |      |          | Industry, | China | State    | Institute | of Pharmaceutical |                   | Industry, |
0.10 mol) and benzyl alcohol (59.5 g, 0.55 mol) were 201203 Shanghai, China; orcid.org/0000-0002-1604-
sequentiallychargedintothereactionmixture.Subsequently,1 816X; Email: sxzlb@263.net
| EDC·HCl    | (105.5   | g, 0.55 | mol) was | added        | in batches | to the      |          |     |          |           |     |                   |     |
| ---------- | -------- | ------- | -------- | ------------ | ---------- | ----------- | -------- | --- | -------- | --------- | --- | ----------------- | --- |
| reaction   | solution | within  | 30 min   | with         | the        | temperature | Authors  |     |          |           |     |                   |     |
| maintained | below    | 10 °C.  | Once     | this mixture | was        | added, the  |          |     | −        |           |     |                   |     |
|            |          |         |          |              |            |             | Chuanjun | Wu  | Shanghai | Institute |     | of Pharmaceutical |     |
reactiontemperaturewasincreasedtoroomtemperaturefor2 Industry, China State Institute of Pharmaceutical Industry,
h; HPLC showed that the reactant was less than 1%. To 201203 Shanghai, China
quenchthereaction,500mLofwaterwassubsequentlyadded. Heng Guo − Shanghai Institute of Pharmaceutical Industry,
The organic layer was separated, and the remaining aqueous China State Institute of Pharmaceutical Industry, 201203
layer was then back-extracted with 100 mL of DCM. The Shanghai, China
organic layers were combined, washed with water, and Jiawei Tang − Shanghai Institute of Pharmaceutical Industry,
concentrated to produce a yellow oily liquid, which was used China State Institute of Pharmaceutical Industry, 201203
in the subsequent reaction without further purification. Shanghai, China
3-(Methylsulfonyl)-phenylmethyl Ester Hydrochloride 1· Lintao Xia − Shanghai Institute of Pharmaceutical Industry,
HCl.Theyellowoilyliquid10wasdissolvedinEtOAc(1.0L).
|     |     |     |     |     |     |     | China | State | Institute | of Pharmaceutical |     | Industry, | 201203 |
| --- | --- | --- | --- | --- | --- | --- | ----- | ----- | --------- | ----------------- | --- | --------- | ------ |
Then, HCl isopropanol solution (4.0 M, 250.0 mL) was Shanghai, China
dropped over a period of 30 min at 20−30 °C. The mixture JianfenShao−ZhejiangBoxiaoBio-PharmaceuticalCo.,Ltd.,
was stirred for an additional 4 h at 65 °C. With reaction Hangzhou 311404, China
progression, the crude product precipitated out from the Yongfu He − Zhejiang Boxiao Bio-Pharmaceutical Co., Ltd.,
reaction mixture and the resulting suspension was gradually Hangzhou 311404, China
cooled back to 20−25 °C for 1 h to precipitate the crystals. Fei Chen − Zhejiang Boxiao Bio-Pharmaceutical Co., Ltd.,
Subsequently,theprecipitatedsolidwascollectedviafiltration Hangzhou 311404, China
|     |     |     |     |     |     |     | 702 |     |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | ---------------------------------------- | --- | --- |
Org.ProcessRes.Dev.2024,28,693−703

Organic Process Research & Development pubs.acs.org/OPRD Article
Peng Peng − Collaborative Innovation Center of Yangtze (14)Zhou,X.;Li,X.;Zhang,W.;Chen,J.Anoveltransitionmetal-
River Delta Region Green Pharmaceuticals, Zhejiang free conjugate reduction of α, β-unsaturated ketones with
University of Technology, Hangzhou 310014, China tosylhydrazine as a hydrogen source. Tetrahedron Lett. 2014, 55,
|        |     | −       |              |     |          |     |     | 5137−5140. |     |     |     |     |     |     |     |
| ------ | --- | ------- | ------------ | --- | -------- | --- | --- | ---------- | --- | --- | --- | --- | --- | --- | --- |
| Yuewen | Han | College | of Chemistry | and | Chemical |     |     |            |     |     |     |     |     |     |     |
(15)Xu,X.J.;Wang,F.;Zeng,T.;Lin,J.;Liu,J.;Chang,Y.Q.;Sun,
| Engineering, |     | Shanghai | University | of Engineering |     | Science, |     |     |     |     |     |     |     |     |     |
| ------------ | --- | -------- | ---------- | -------------- | --- | -------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
P.H.;Chen,W.M.4-arylamidobenzylsubstitutes5-bromomethylene-
| 201620 | Shanghai, | China |     |     |     |     |     |                 |     |             |           |            |     |              |       |
| ------ | --------- | ----- | --- | --- | --- | --- | --- | --------------- | --- | ----------- | --------- | ---------- | --- | ------------ | ----- |
|        |           |       |     |     |     |     |     | 2(5H)-furanones |     | for chronic | bacterial | infection. |     | Eur. J. Med. | Chem. |
Complete contact information is available at: 2018, 144, 164−178.
https://pubs.acs.org/10.1021/acs.oprd.3c00358 (16) Lozinskaya, N.; Sosonyuk, S.; Volkova, M.; Seliverstov, M.;
Proskurnina,M.;Bachurin,S.;Zefirov,N.Simplesynthesisofsome2-
|     |     |     |     |     |     |     |     | substitutedmelatonin |     | derivatives.Synthesis |     |     | 2011, | 273−276. |     |
| --- | --- | --- | --- | --- | --- | --- | --- | -------------------- | --- | --------------------- | --- | --- | ----- | -------- | --- |
Notes
(17)Simons,C.;vanLeeuwen,J.G.E.;Stemmer,R.;Arends,I.W.
| The authors | declare | no competing |     | financial | interest. |     |     |                    |     |     |          |     |               |            |     |
| ----------- | ------- | ------------ | --- | --------- | --------- | --- | --- | ------------------ | --- | --- | -------- | --- | ------------- | ---------- | --- |
|             |         |              |     |           |           |     |     | C. E.; Maschmeyer, |     | T.; | Sheldon, | R.  | A.; Hanefeld, | U. Enzyme- |     |
■
catalyzeddeprotectionofN-acetylandN-formylaminoacids.J.Mol.
ACKNOWLEDGMENTS
|     |     |     |     |     |     |     |     | Catal. B:Enzym. |     | 2008, 54,67−71. |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --------------- | --- | --------------- | --- | --- | --- | --- | --- |
(18)Trott,O.;Olson,A.J.AutoDockvina:Improvingthespeedand
| This work        | was | financially | supported    | by      | the     | National | Key   |               |            |                 |     |             |       |                     |      |
| ---------------- | --- | ----------- | ------------ | ------- | ------- | -------- | ----- | ------------- | ---------- | --------------- | --- | ----------- | ----- | ------------------- | ---- |
|                  |     |             |              |         |         |          |       | accuracy      | of docking | with            | a   | new scoring |       | function, efficient |      |
| Research         | and | Development |              | Program |         | of       | China |               |            |                 |     |             |       |                     |      |
|                  |     |             |              |         |         |          |       | optimization, | and        | multithreading. |     | J. Comput.  | Chem. | 2010, 31,           | 455− |
| (2021YFC2102100) |     |             | and Shanghai |         | Sailing | Program  |       |               |            |                 |     |             |       |                     |      |
461.
| (23YF1445800). |                   | The authors | are      | grateful | to the   | China | State  |             |     |         |             |     |            |              |     |
| -------------- | ----------------- | ----------- | -------- | -------- | -------- | ----- | ------ | ----------- | --- | ------- | ----------- | --- | ---------- | ------------ | --- |
|                |                   |             |          |          |          |       |        | (19) Herga, | S.; | Brutus, | A.; Vitale, | R.  | M.; Miche, | H.; Perrier, | P.; |
| Institute      | of Pharmaceutical |             | Industry | and      | Zhejiang |       | Boxiao |             |     |         |             |     |            |              |     |
Puigserver,A.;Scaloni,A.;Giardina,T.Site-directedmutagenesisand
Biopharmaceutical Co., Ltd., for financial support. molecularmodellingstudiesshowtheroleofAsp82andcysteinesin
■ rat acylase 1, a member of the M20 family. Biochem. Biophys. Res.
| REFERENCES |     |     |     |     |     |     |     | Commun.2005, | 330, | 540−546. |     |     |     |     |     |
| ---------- | --- | --- | --- | --- | --- | --- | --- | ------------ | ---- | -------- | --- | --- | --- | --- | --- |
(20)Wei,T.Y.;Tang,J.W.;Ni,G.W.;Wang,H.Y.;Yi,D.;Zhang,
| (1) Haber, | S. L.;       | Benson,         | V.; Buckway, |         | C. J.; Gonzales, |              | J. M.; |              |     |                |     |       |           |         |         |
| ---------- | ------------ | --------------- | ------------ | ------- | ---------------- | ------------ | ------ | ------------ | --- | -------------- | --- | ----- | --------- | ------- | ------- |
|            |              |                 |              |         |                  |              |        | F. L.; Chen, | S.  | X. Development |     | of an | enzymatic | process | for the |
| Romanet,   | D.; Scholes, | B. Lifitegrast: |              | A novel | drug             | for patients | with   |              |     |                |     |       |           |         |         |
synthesisof(S)-2-chloro-1-(2,4-dichlorophenyl)ethanol.Org.Process
| dry eye | disease. | Ther. | Adv. | Ophthalmol. |     | 2019, | 11, |                |               |     |     |     |     |     |     |
| ------- | -------- | ----- | ---- | ----------- | --- | ----- | --- | -------------- | ------------- | --- | --- | --- | --- | --- | --- |
|         |          |       |      |             |     |       |     | Res. Dev.2019, | 23,1822−1828. |     |     |     |     |     |     |
No. 2515841419870366.
(21)Guo,X.;Tang,J.W.;Yang,J.T.;Ni,G.W.;Zhang,F.L.;Chen,
(2)Zhong,M.;Gadek,T.R.;Bui,M.;Shen,W.;Burnier,J.;Barr,K.
S.X.Developmentofapracticalenzymaticprocessforpreparationof
J.;Hanan,E.J.;Oslob,J.D.;Yu,C.H.;Zhu,J.;etal.Discoveryand
|             |           |              |          |            |       |          |          | (S)-2-chloro-1-(3,4-difluorophenyl) |            |           |        | ethanol.  | Org. | Process Res.  | Dev.   |
| ----------- | --------- | ------------ | -------- | ---------- | ----- | -------- | -------- | ----------------------------------- | ---------- | --------- | ------ | --------- | ---- | ------------- | ------ |
| development | of potent | LFA-1/ICAM-1 |          | antagonist |       | SAR 1118 | as an    |                                     |            |           |        |           |      |               |        |
|             |           |              |          |            |       |          |          | 2017, 21,                           | 1595−1601. |           |        |           |      |               |        |
| ophthalmic  | solution  | to treat     | dry eye. | ACS Med.   | Chem. | Lett.    | 2012, 3, |                                     |            |           |        |           |      |               |        |
|             |           |              |          |            |       |          |          | (22) Wang,                          | H.         | Y.; Tang, | J. W.; | Peng, P.; | Yan, | H. J.; Zhang, | F. L.; |
203−206.
Chen,S.X.Developmentofanovelchemoenzymaticprocessfor(S)-
| (3) Li,     | G.; Li,      | K. J.; Huang,              | X.  | P.; Yin, | D. H. | Preparation | of   |                     |     |                |     |              |     |                 |     |
| ----------- | ------------ | -------------------------- | --- | -------- | ----- | ----------- | ---- | ------------------- | --- | -------------- | --- | ------------ | --- | --------------- | --- |
|             |              |                            |     |          |       |             |      | 1-(pyridin-4-yl)-1, |     | 3-propanediol. |     | Org. Process |     | Res. Dev. 2020, | 24, |
| Lifitegrast | Intermediate | ((2S)-2-Amino-3-(3-methane |     |          |       | Sulfonyl    | Phe- |                     |     |                |     |              |     |                 |     |
2890−2897.
| nyl)Propanoic           | Acid.   | CNPatent.  | CN113072471A2021. |                  |                 |                 |      |                 |     |            |            |               |     |              |         |
| ----------------------- | ------- | ---------- | ----------------- | ---------------- | --------------- | --------------- | ---- | --------------- | --- | ---------- | ---------- | ------------- | --- | ------------ | ------- |
|                         |         |            |                   |                  |                 |                 |      | (23) Anderson,  |     | G. W.;     | Zimmerman, |               | E.; | Callahan, F. | M. A    |
| (4) Combs,              | A. P.;  | Robert,    | W. A.             | Characterization |                 | of α-halo-imine |      |                 |     |            |            |               |     |              |         |
|                         |         |            |                   |                  |                 |                 |      | reinvestigation | of  | the mixed  | carbonic   | anhydride     |     | method of    | peptide |
| intermediates           | derived | from       | halogenation      |                  | of dehydroamino |                 | acid |                 |     |            |            |               |     |              |         |
|                         |         |            |                   |                  |                 |                 |      | synthesis.J.    | Am. | Chem. Soc. | 1967,      | 89,5012−5017. |     |              |         |
| derivatives.Tetrahedron |         | Lett.1992, |                   | 33,6419−6422.    |                 |                 |      |                 |     |            |            |               |     |              |         |
(24)Zheng,B.F.;Li,S.L.;Gao,Q.;Ma,Z.B.;Liu,G.;Yang,C.W.;
(5)Mesaik,M.A.;Rahat,S.;Khan,K.M.;Zia-Ullah;Choudhary,M.
|     |     |     |     |     |     |     |     | Mei, K.; | Sun, J. | J.; Huang, | Y. B. | A Method | for | the Preparation | of  |
| --- | --- | --- | --- | --- | --- | --- | --- | -------- | ------- | ---------- | ----- | -------- | --- | --------------- | --- |
I.;Murad,S.;Ismail,Z.;Ahmad,A.Synthesisandimmunomodulatory
|     |     |     |     |     |     |     |     | LifitegrastIntermediate. |     | CNPatent. |     | CN111471003A2020. |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | ------------------------ | --- | --------- | --- | ----------------- | --- | --- | --- |
propertiesofselectedoxazolonederivatives.Bioorg.Med.Chem.2004,
12,2049−2057.
(6)Cleary,T.;Brice,J.;Kennedy,N.;Flavio,C.One-potprocessto
| Z-α-benzoyl         | amino-acrylic |            | acid      | methyl      | esters | via potassium |       |     |     |     |     |     |     |     |     |
| ------------------- | ------------- | ---------- | --------- | ----------- | ------ | ------------- | ----- | --- | --- | --- | --- | --- | --- | --- | --- |
| phosphate-catalyzed |               | Erlenmeyer | reaction. | Tetrahedron |        | Lett.         | 2010, |     |     |     |     |     |     |     |     |
51,625−628.
| (7) Periasamy, | M.; | Thirumalaikumar, |     | M. Methods |     | of enhancement |     |     |     |     |     |     |     |     |     |
| -------------- | --- | ---------------- | --- | ---------- | --- | -------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
ofreactivityandselectivityofsodiumborohydrideforapplicationsin
| organic synthesis.J. |     | Organomet.Chem. |     | 2000, | 609,137−151. |     |     |     |     |     |     |     |     |     |     |
| -------------------- | --- | --------------- | --- | ----- | ------------ | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
(8)Wu,H.;Moeller,K.D.AnodicCouplingReactions:Asequential
| cyclization | route to | the arteannuin |     | ring skeleton. | Org. | Lett. | 2007, 9, |     |     |     |     |     |     |     |     |
| ----------- | -------- | -------------- | --- | -------------- | ---- | ----- | -------- | --- | --- | --- | --- | --- | --- | --- | --- |
4599−4602.
(9)Kurose,T.;Tsukano,C.;Takemoto,Y.Synthesisofoctahydro-
| and decahydroquinolines                |           |               | by a      | one-pot        | cascade       | reaction     | of    |     |     |     |     |     |     |     |     |
| -------------------------------------- | --------- | ------------- | --------- | -------------- | ------------- | ------------ | ----- | --- | --- | --- | --- | --- | --- | --- | --- |
| tetrasubstitutedenecarbamate.Org.Lett. |           |               |           | 2017,          | 19,4762−4765. |              |       |     |     |     |     |     |     |     |     |
| (10) Nocquet,                          | P.        | A.; Hazelard, |           | D.; Compain,   |               | P. Synthesis | of    |     |     |     |     |     |     |     |     |
| spirocyclopropyl                       | γ-lactams |               | by tandem | intramolecular |               | azetidine    | ring- |     |     |     |     |     |     |     |     |
opening/closingcascadereaction:Syntheticandmechanisticaspects.
| Tetrahedron2012, |     | 68, 4117−4128. |     |     |     |     |     |     |     |     |     |     |     |     |     |
| ---------------- | --- | -------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
(11)Richmond,E.;Duguet,N.;Slawin,A.M.Z.;Lébl,T.;Smith,A.
| D. Asymmetric   | pericyclic  | cascade      | approach     |                  | to spirocyclic | oxindoles. |        |     |     |     |     |     |     |     |     |
| --------------- | ----------- | ------------ | ------------ | ---------------- | -------------- | ---------- | ------ | --- | --- | --- | --- | --- | --- | --- | --- |
| Org.Lett.2012,  | 14,         | 2762−2765.   |              |                  |                |            |        |     |     |     |     |     |     |     |     |
| (12) Kotek,     | V.;         | Dvorá̌ ková, | H.; Tobrman, |                  | T. Modular     | and        | highly |     |     |     |     |     |     |     |     |
| stereoselective | approach    | to           | all-carbon   | tetrasubstituted |                | alkenes.   | Org.   |     |     |     |     |     |     |     |     |
| Lett.2015,      | 17,608−611. |              |              |                  |                |            |        |     |     |     |     |     |     |     |     |
(13)Chen,H.;Wang,J.M.;Hong,X.C.;Zhou,H.B.;Dong,C.A
| simple and  | straightforward |     | approach | toward | selective    | C�C | bond |     |     |     |     |                                          |     |     |     |
| ----------- | --------------- | --- | -------- | ------ | ------------ | --- | ---- | --- | --- | --- | --- | ---------------------------------------- | --- | --- | --- |
| reductionby | hydrazine.Can.  |     | J. Chem. | 2012,  | 90, 758−761. |     |      |     |     |     |     |                                          |     |     |     |
|             |                 |     |          |        |              |     |      | 703 |     |     |     | https://doi.org/10.1021/acs.oprd.3c00358 |     |     |     |
Org.ProcessRes.Dev.2024,28,693−703