多拉菌素API及其已知杂质结构式

|  |  |
| --- | --- |
| 名称 | 结构式 |
| 多拉菌素API | ![IMG_256](data:image/gif;base64...) |
| 阿维菌素B1a  (杂2) | ![C:\Users\Administrator\Desktop\QQ截图20170901164310.png](data:image/png;base64...) |
| 14-去甲基多拉菌素  （杂3） | ![](data:image/x-emf;base64...) |
| 3,4-二氢多拉菌素  （杂4） | ![](data:image/x-emf;base64...) |
| 5-脱羟基-5-羰基-多拉菌素  （杂5） | ![](data:image/x-emf;base64...) |
| 阿维菌素B1b  （杂质6） | ![](data:image/x-emf;base64...) |
| 6,8a-二氢-25-环己基-5-O-去甲基-25-去（1-甲基丙基）阿维菌素A1a  （杂质7） | ![](data:image/x-emf;base64...) |