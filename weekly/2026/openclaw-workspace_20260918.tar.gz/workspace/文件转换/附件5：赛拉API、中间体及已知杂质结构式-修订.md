API、中间体及已知杂质结构式

1. 赛拉菌素结构式：

![](data:image/png;base64...)

2、赛拉菌素中间体：

|  |  |
| --- | --- |
| 中间体名称 | 中间体结构 |
| 氢化物 | ![C:\Users\ZC-02\AppData\Local\Temp\WeChat Files\477847554953311410.jpg](data:image/jpeg;base64...) |
| 氧化物 | ![氧化物](data:image/png;base64...) |

3、赛拉菌素已知杂质结构：

|  |  |
| --- | --- |
| 杂质名称 | 杂质结构 |
| 杂质A | **![](data:image/png;base64...)** |
| 杂质B | **![](data:image/png;base64...)** |
| 杂质C | ![](data:image/png;base64...) |
| 杂质D | ![](data:image/png;base64...) |
| RRT 0.63 | ![](data:image/png;base64...) |
| RRT 1.35 | ![](data:image/png;base64...) |