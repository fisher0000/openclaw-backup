---
name: lobster-daily-generator
description: |
  强制自动化日报生成技能 - v3.29

  **适用范围：** v3.4+ 仅适用于珠海合成。其他用户/部署不适用此版本。

  **许可证：** 专有许可证 - 仅限 丽珠医药 内部使用，禁止外部分发。详见 `LICENSE` 文件。

  **核心特性**:
  1. **零人工干预** - 用户只能触发，不能修改内容
  2. **100% 真实数据** - 从所有 agent 的 session 历史、工具调用记录采集
  3. **禁止虚假内容** - 自动过滤虚词（学习了、计划、准备等）
  4. **强制标准格式** - 严格按 v2.0 模板 6 大模块输出
  5. **时区安全** - 所有时间计算使用 Asia/Shanghai (GMT+8)，不依赖系统本地时间
---

# Lobster Daily Generator 

> 本文件为**人类阅读文档**，用于说明设计、规则、数据来源与历史变更。
> 真正供 OpenClaw 执行的约束与命令入口，请以 `SKILL.md` 为准。

---

## 🚨 核心原则（不可违背）

| 原则 | 允许 | 禁止 |
|------|------|------|
| **零人工干预** | 用户触发执行（手动或定时） | 用户修改/补充/编辑内容 |
| **100% 真实数据** | 读取 session JSONL、调用 Feishu API | 用户输入、推测估算、模糊词 |
| **禁止虚假内容** | 自动过滤虚词 | "学习了"、"计划"、"一些"等 |
| **强制标准格式** | 严格按 6 大模块输出 | 自定义格式、增删模块 |

### 虚词黑名单（自动过滤）

| 类别 | 词例 |
|------|------|
| 学习类 | 学习了、了解了、掌握了、熟悉了、研究了、探索了 |
| 计划类 | 计划、准备、打算、将要、拟、规划 |
| 模糊类 | 一些、若干、部分、大概、可能、也许、差不多 |
| 主观类 | 觉得、认为、感觉、应该、想必、估计 |

---

## 📋 快速索引

| 用户意图 | 操作方式 | 说明 |
|---------|---------|------|
| 自动生成日报 | 定时触发（每日 16:00） | 自动执行，节假日判断 |
| 手动生成日报 | `python3 scripts/daily_generator.py --user <union_id>` | 立即生成指定用户日报 |
| 测试模式 | `python3 scripts/daily_generator.py --test` | 不发送，只输出到控制台 |
| 验证数据 | `python3 scripts/daily_generator.py --validate --user <union_id>` | 验证数据完整性 |
| 查看过滤报告 | `python3 scripts/daily_generator.py --filter-report` | 查看虚词过滤情况 |

---

## 🎯 工作原理

### 数据流

```
session JSONL 文件 ──┐
                     ├──→ 数据采集 ──→ 虚词过滤 ──→ 模块组装 ──→ 输出
git 提交历史    ──┘                    ↓
Feishu API     ───────────────→ 身份解析
```

### 数据来源

| 数据项 | 来源 | 说明 |
|--------|------|------|
| 会话数据 | `~/**/sessions/*.jsonl` | 所有 agent 的 session 记录 |
| 文件变更 | `workspace-*/` git log | 所有工作区的提交历史 |
| 用户身份 | Feishu Contact API | 从 openclaw.json 配置解析 |

### 时间窗口

日报覆盖的时间窗口为 **上一个工作日 16:00 → 今日 16:00**：

| 触发时间 | 窗口起点 | 窗口终点 |
|----------|----------|----------|
| 周一 16:00 | 上周五 16:00 | 周一 16:00 |
| 周二~周五 16:00 | 前一日 16:00 | 今日 16:00 |
| 周末/节假日 | 最近工作日 16:00 | 下一工作日 16:00 |

**节假日判断逻辑**：
1. 查询 `https://api.jiejiariapi.com/v1/holidays/{year}` 获取中国节假日安排（含调休）
2. `isOffDay=true` → 假期，窗口顺延
3. `isOffDay=false` → 调休工作日，按正常工作日处理
4. 不在 API 返回中且为周一~五 → 正常工作日
5. 不在 API 返回中且为周末 → 正常休息日

---

## 📊 核心算法

### 1. Session 文件扫描

**目标**：从磁盘中采集所有 session 数据，排除临时/快照文件。

**扫描逻辑**：
```
1. 递归搜索 ~/ 下所有名为 "sessions" 的目录（最大深度 5 层）
2. 对每个目录中的 *.jsonl 文件：
   - 排除包含 ".deleted." 的文件（已删除备份）
   - 排除包含 ".checkpoint." 的文件（v3.28 修复，分支快照）
   - 排除以 ".lock" 结尾的文件（锁文件）
   - **包含** `.reset.` 文件（时间戳窗口过滤已避免重复计数）
3. 解析每个 JSONL 文件，提取：
   - timestamp: 消息时间戳
   - role: user 或 assistant
   - toolCall: 工具调用记录
4. 过滤时间窗口内的消息
```

**文件示例**：
```
~/
└── .openclaw/
    └── agents/
        └── main/
            └── sessions/
                ├── abc123.jsonl           ← 有效
                ├── def456.jsonl           ← 有效
                ├── abc123.reset.2026-04-15T04-00-00.000Z  ← 有效
                ├── abc123.checkpoint.1    ← 排除（快照）
                ├── abc123.checkpoint.2    ← 排除（快照）
                └── abc123.deleted         ← 排除（已删除）
```

---

### 2. 使用时长计算（Active Period Sum）

**目标**：计算实际活跃时间，排除空闲时段。

**算法**：
```
1. 收集所有 session 的消息时间戳（已过滤时间窗口）
2. 按时间排序
3. 遍历时间戳，计算相邻消息间隔：
   - 间隔 ≤ 10 分钟 → 同一活跃时段
   - 间隔 > 10 分钟 → 新活跃时段开始
4. 累加所有活跃时段的时长
```

**示例**：
```
消息时间：09:00, 09:05, 12:00, 12:05

旧方法（session span）:
  09:00 → 12:05 = 185 分钟 ❌（包含 3 小时空闲）

新方法（Active Period Sum）:
  活跃时段 1: 09:00-09:05 = 5 分钟
  活跃时段 2: 12:00-12:05 = 5 分钟
  总计：10 分钟 ✅
```

**关键点**：
- 10 分钟阈值：间隔 > 10 分钟视为空闲
- 多会话时间戳合并后排序，自动处理重叠（不重复计数）
- 返回分钟数（至少 1 分钟，若有活动）

---

### 3. 消息计数

**目标**：统计用户与助手的消息往来。

**计数逻辑**：
```
对每个 session JSONL 文件：
  对每行 entry：
    if entry.type == 'message':
      if entry.message.role == 'user':
        messages_sent += 1
      elif entry.message.role == 'assistant':
        messages_received += 1
      message_count += 1
```

**排除项**：
- `entry.type == 'session'` → session 元数据
- `entry.type == 'toolCall'` → 工具调用（单独统计）
- `entry.type == 'toolResult'` → 工具结果
- `entry.type == 'checkpoint'` → 状态快照

---

### 4. 身份解析（Identity Resolution）

**目标**：从配置中解析用户真实姓名和应用名称。

**API 调用链**：
```
openclaw.json
    ↓ (读取 app_id, app_secret)
POST /auth/v3/tenant_access_token/internal
    ↓ (返回 tenant_access_token)
GET /application/v6/applications/{app_id}
    ↓ (返回 owner.owner_id)
GET /contact/v3/users/{owner_id}?user_id_type=open_id
    ↓ (返回 union_id)
GET /contact/v3/users/{union_id}?user_id_type=union_id
    ↓ (返回 user.name)
user_name = user.name
```

**用途**：
- 本地文件名：`daily_report_{user_name}_{app_name}_{date}.md`
- 报告标题：`# 日报 - {user_name} ({union_id}) - {date}`
- 飞书文档标题：同上

**Fallback**：若 API 调用失败，使用 `--user` 参数传入的 union_id 直接透传。

---

### 5. 文件变更追踪

**目标**：统计工作区文件的新建/修改情况。

**追踪逻辑**：
```
1. 递归搜索 ~/ 下所有 "workspace-*" 目录
2. 对每个工作区：
   a. 优先使用 git log：
      - git log --since={date}T00:00 --until={date}T23:59 --name-only
      - 获取今日提交的文件列表
   b. 若无 git，回退到 mtime 扫描：
      - 遍历文件，检查 mtime 是否在今日
3. 排除目录：__pycache__, .git, node_modules, logs 等
4. 排除扩展：.pyc, .log, .png, .mp4 等
5. 只追踪有意义的文件：.py, .js, .md, .json, .yaml 等
```

---

## 📄 输出格式

### 报告结构（6 大模块）

```markdown
# 日报 - {user_name} ({union_id}) - {date}

## 一、今日使用概览
- 会话次数：{N} 次
- 使用时长：{N} 分钟（约 {N} 小时）
- 工具调用：{N} 次
- 活跃时段：HH:MM-HH:MM

## 二、核心成果交付
- 具体完成事项 1（量化数据）
- 具体完成事项 2（量化数据）

## 三、技能学习记录
- 使用的技能列表

## 四、问题与异常
- 遇到的错误或障碍

## 五、明日工作建议
- 基于今日数据的建议

## 六、使用心得与反思
- 真实使用感受

---
*本日报由系统自动生成，数据来源：session 历史、工具调用记录*
*生成时间：{timestamp}*
```

### 输出位置（一式两份）

| 类型 | 位置 | 命名规则 |
|------|------|----------|
| 飞书云文档 | 指定文件夹 | `daily_report_{user_name}_{app_name}_{date}.md` |
| 本地文件 | `logs/daily_reports/` | 同上 |

---

## 🔧 配置说明

### 配置格式支持

| 格式 | 示例 |
|------|------|
| 直接字符串 | `"appId": "cli_xxx"` |
| 文件引用 | `"appId": "${file:~/.secrets/app_id}"` |
| 字典格式 | `"appId": {"secrets.json": null}` |
| Secret Provider | `"appSecret": {"provider": "miaoda-secret-provider", "id": "..."}` |

### 所需 Feishu 权限（tenant_access_token）

| API | 权限 | 用途 |
|-----|------|------|
| `GET /application/v6/applications/{app_id}` | `application:application:readonly` | 获取应用信息 |
| `GET /contact/v3/users/{id}` | `contact:user.base:readonly` | 获取用户信息 |
| `POST /docx/v1/documents` | `docx:document:create` | 创建云文档 |
| `POST /docx/v1/documents/{id}/blocks/{id}/children` | `docx:document:write` | 写入内容 |
| `PATCH /drive/v2/permissions/{id}/public` | `docs:permission.setting` | 设置权限 |

**权限缺失处理**：脚本启动时自动检查权限，缺失时报错并提示联系管理员。

---

## 🚀 使用示例

### 定时自动生成（推荐）

```javascript
// 每日 16:00 自动生成（脚本自动判断节假日）
cron.add({
  name: "日报生成",
  schedule: { kind: "cron", expr: "0 16 * * *", tz: "Asia/Shanghai" },
  payload: {
    kind: "agentTurn",
    message: `cd ~/skills/lobster-daily-generator/scripts && python3 daily_generator.py --auto`
  },
  sessionTarget: "isolated"
})
```

**`--auto` 模式行为：**
- 查询 `https://api.jiejiariapi.com/v1/holidays/{year}` 获取中国节假日安排
- `isOffDay=true` → 假期，**跳过生成**
- `isOffDay=false` → 调休工作日，**正常生成**
- 不在 API 返回中且为周一~五 → 正常工作日，**正常生成**
- 不在 API 返回中且为周末 → 正常休息日，**跳过生成**

**注意：** `--auto` 仅用于定时任务。手动调用时不加 `--auto`，直接生成。

### 手动生成

```bash
# 生成指定用户的日报
python3 scripts/daily_generator.py --user on_xxx --date 2026-03-19

# 测试模式（不发送）
python3 scripts/daily_generator.py --test --user on_xxx
```

---

## 🔍 常见问题

| 错误现象 | 原因 | 解决方案 |
|---------|------|---------|
| 数据获取失败 | session 文件权限不足 | 检查 `~/**/sessions/` 目录权限 |
| 模块缺失 | 某模块无数据 | 标记为"无相关数据" |
| 主体错误 | 检测到 AI 主体 | 自动修正或标记警告 |
| 虚词过多 | 内容含大量虚词 | 过滤并提示 |
| 生成失败 | 数据不足 | 提示"今日无使用记录" |
| 权限不足 | Feishu API 权限缺失 | 联系管理员在开放平台添加权限 |

---

## 📚 附录

### 日志位置

```
logs/
├── daily_generator.log           # 主日志
├── daily_reports/                # 生成的日报
├── validation_reports/           # 验证报告
└── filter_reports/               # 过滤报告
```

### 质量检查（供考核系统参考）

| 维度 | 检查项 | 通过标准 |
|:---|:---|:---|
| **完整性** | 6 大模块齐全 | 6 个模块都包含 |
| **主体正确性** | 无 AI 主体 | 不含"AI 助手"等词 |
| **数据准确性** | 有具体数字 | 量化数据占比>50% |
| **业务价值** | 有硬核产出 | 可验证的成果 |
| **创新性** | 有创新点 | 新技能/新方法 |
| **表达质量** | 格式规范 | 符合模板要求 |

---

## 变更记录

| 版本 | 日期 | 变更内容 |
|------|------|----------|
| v3.29 | 2026-05-06 | `--auto` 模式新增节假日自动跳过：查询 `api.jiejiariapi.com`，`isOffDay=true` 时直接退出不生成；手动模式不受影响；v3.28→v3.29 |
| v3.28 | 2026-04-15 | 修复 session 文件扫描：排除 `.checkpoint.` 文件，避免重复计数；恢复包含 `.reset.` 文件（时间戳窗口过滤已避免重复计数）；v3.27→v3.28 |
| v3.27 | 2026-04-14 | 修复 header 清理引入的 bug：恢复 `import os`；v3.26→v3.27 |
| v3.26 | 2026-04-13 | 使用时长计算优化：实现"Active Period Sum"，排除空闲时间；v3.25→v3.26 |
| v3.25 | 2026-04-06 | 文件变更追踪扩展至所有 `workspace-*` 目录；HTTP 错误处理增强；v3.24→v3.25 |
| v3.24 | 2026-03-25 | 修复 Windows 编码问题：所有 `read_text()` 添加 `encoding='utf-8'`；v3.23→v3.24 |
| v3.23 | 2026-03-25 | 修复时间窗口过滤逻辑；v3.22→v3.23 |
| v3.22 | 2026-03-25 | 修复文件扫描错误处理：跳过损坏的符号链接和不可访问路径；v3.21→v3.22 |
| v3.21 | 2026-03-25 | 权限检查强制要求 `tenant_access_token`；v3.20→v3.21 |
| v3.20 | 2026-03-24 | 节假日 API 改为 `api.jiejiariapi.com`（支持调休）；v3.19→v3.20 |
| v3.19 | 2026-03-24 | 添加作者信息；`accounts` 支持列表格式；v3.18→v3.19 |
| v3.18 | 2026-03-24 | 身份识别改为 `union_id` 链；补全权限表；v3.17→v3.18 |
| v3.17 | 2026-03-24 | `SKILL.md` 收敛为严格执行契约；v3.16→v3.17 |
| v3.16 | 2026-03-23 | 统一版本号与文档；v3.15→v3.16 |
| v3.15 | 2026-03-23 | 添加 Feishu API 权限检查；v3.14→v3.15 |
| v3.14 | 2026-03-23 | 修复 `_get_user_name()` fallback；v3.13→v3.14 |
| v3.13 | 2026-03-23 | 修复初始化顺序；`--user` 改为可选；v3.12→v3.13 |
| v3.12 | 2026-03-23 | 身份识别返回真实 Open ID；v3.11→v3.12 |
| v3.11 | 2026-03-23 | 支持文件引用占位符和 secret provider；v3.10→v3.11 |
| v3.10 | 2026-03-23 | session 文件搜索改为递归 `~/` 下所有 `sessions` 目录；v3.9→v3.10 |
| v3.9 | 2026-03-23 | 时区处理改为 Asia/Shanghai timezone-aware；v3.8→v3.9 |
| v3.8 | 2026-03-22 | 移除 markdown 标题中的 app_name；v3.7→v3.8 |
| v3.7 | 2026-03-22 | 移除硬编码 APP_ID；自适应 ThreadPoolExecutor；v3.6→v3.7 |
| v3.6 | 2026-03-22 | 统一文件名与文档标题；添加身份解析；v3.5→v3.6 |
| v3.5 | 2026-03-21 | 统一 6 大模块；更正自动生成时间为 16:00；v3.4→v3.5 |
| v3.4 | 2026-03-20 | 修复日期窗口和 st_mtime 过滤；v3.3→v3.4 |
| v3.3 | 2026-03-20 | 支持跨 agent 数据采集；v3.2→v3.3 |
| v3.2 | 2026-03-20 | 重写 DataCollector，直接读取 session transcript；v3.1→v3.2 |
| v3.1 | 2026-03-20 | 修复工具调用；v3.0→v3.1 |
| v2.0 | 2026-03-20 | 强制自动化日报生成；v1.0→v2.0 |
| v1.0 | 2026-03-20 | 初始版本 |
