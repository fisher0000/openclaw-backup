---
title: Claim Info Page
source: https://unclaimedproperty.delaware.gov/app/claim-info
author:
published:
created: 2026-04-15
description:
tags:
  - clippings
---
FAST: Just minutes to complete!  
EASY: Minimal Information necessary!  
SAFE: We take the greatest care to encrypt your data, making sure that your information remains protected.  
SECURE: Site secured by DigiCert SSL Technology. All information will remain confidential and ONLY used for processing your claim.

If you are attempting to claim securities-related property, and you have filed your claim after July 1, 2017 and within 18 months of the date notice was mailed to you by the State Escheator, you may receive the applicable replacement of the security or the market value of the security as of the date the claim is filed. This election must be made when the claim is initiated and cannot be amended during the claims process. If you do not make an election, you will receive the cash value of any securities-related property in your claim s of the date the claim was filed.  
  
If applicable, and you elect to be reunited with your shares, you will be required to provide the name, DTC number, account number, direct contact name, direct contact phone number, and direct contact e-mail address of a U.S. Brokerage firm (not a transfer agent) where you maintain a current and active account. You will also be asked to validate the owner name on the account information provided. This is a different account than the account from which your shares may have been escheated because most brokers and transfer agents close the originating stock account at time of property escheatment. The State will attempt to transfer your shares to the account information you provide, but this does not guarantee that you will receive the applicable shares. If you fail to provide the necessary U.S. Brokerage firm information as detailed above, or if the information you provide is incorrect or incomplete, or if the state is unable to complete the transfer request for any reason, you will receive the applicable cash value of the shares instead.  
  
If you have initiated your claim before July 1, 2017, or after 18 months of the date official notice was mailed by the State Escheator, you will receive the net proceeds of the sale of the security, plus dividends, interest, and other increments on the security up to the date of the sale by the State Escheator.

*\* Required field* 