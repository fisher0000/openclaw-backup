# Claude Code 完全使用教程

> 版本: v1.0 | 适用: Claude Code + Obsidian 深度绑定场景 | 作者: 小虾

---

## 目录

1. [Claude Code 是什么](#1-claude-code-是什么)
2. [安装与配置](#2-安装与配置)
3. [基础操作](#3-基础操作)
4. [与 Obsidian 协同工作](#4-与-obsidian-协同工作)
5. [高级功能](#5-高级功能)
6. [实战案例](#6-实战案例)
7. [故障排除](#7-故障排除)
8. [快捷键与技巧](#8-快捷键与技巧)

---

## 1. Claude Code 是什么

Claude Code 是 Anthropic 推出的**终端级 AI 编程助手**，特点：

- **直接操作文件系统** - 读写、编辑、搜索本地文件
- **Git 原生集成** - 自动 commit、diff、branch 管理
- **上下文感知** - 理解整个项目结构，不只是单文件
- **命令行交互** - 在终端中与 AI 对话，效率极高

### 与 OpenClaw 的区别

| 特性 | Claude Code | OpenClaw |
|------|-------------|----------|
| 运行位置 | 你的本地电脑 | 云端服务器 |
| 交互方式 | 终端命令行 | 飞书/消息 |
| 文件访问 | 直接读写本地文件 | 通过 API 操作 |
| 定时任务 | ❌ 不支持 | ✅ 原生支持 |
| 飞书集成 | ❌ 不支持 | ✅ 原生支持 |
| 代码开发 | ✅ 专业级 | ⚠️ 基础支持 |
| 深度编辑 | ✅ 专业级 | ⚠️ 基础支持 |

**结论**: Claude Code 是**本地深度工作终端**，OpenClaw 是**云端自动化中台**，两者互补。

---

## 2. 安装与配置

### 2.1 系统要求

- **操作系统**: macOS 12+ / Windows 10+ / Linux
- **Node.js**: >= 18.0.0
- **Git**: 已安装并配置
- **网络**: 能访问 Anthropic API

### 2.2 安装步骤

#### macOS / Linux

```bash
# 使用 npm 安装
npm install -g @anthropic-ai/claude-code

# 验证安装
claude --version
# 输出示例: 0.2.14
```

#### Windows

```powershell
# 使用 PowerShell (管理员)
npm install -g @anthropic-ai/claude-code

# 验证
claude --version
```

#### 国内网络加速（如需）

```bash
# 使用淘宝镜像
npm config set registry https://registry.npmmirror.com
npm install -g @anthropic-ai/claude-code
```

### 2.3 首次登录

```bash
# 启动 Claude Code
claude

# 会打开浏览器，要求登录 Anthropic 账号
# 登录成功后，终端显示 "Authenticated successfully"
```

### 2.4 配置 Obsidian 绑定（关键步骤）

```bash
# 1. 进入 Obsidian vault 目录
cd "D:\WT\Github\obsidian"    # Windows
cd ~/Documents/obsidian        # macOS/Linux

# 2. 应用配置包（之前发送的 tar.gz）
# 解压配置包到当前目录

# 3. 运行配置脚本
./scripts/setup.sh             # macOS/Linux
.\scripts\setup.bat            # Windows

# 4. 验证配置
ls .claude/CLAUDE.md
ls .claude/commands/
```

---

## 3. 基础操作

### 3.1 启动 Claude Code

```bash
# 方式 1: 直接启动（在 vault 目录）
claude .

# 方式 2: 指定目录启动
claude /path/to/your/project

# 方式 3: 带自定义指令启动
claude . --instructions .claude/CLAUDE.md

# 方式 4: 使用启动脚本（推荐）
./scripts/start-claude.sh
```

### 3.2 基本命令

进入 Claude Code 后，你会看到提示符 `>`

```
# 询问问题
> 什么是 ICH Q11 指导原则？

# 读取文件
> 读取 KB/02-wiki/法规/ICH/Q11.md

# 搜索内容
> 搜索 "起始物料" 相关的所有文档

# 编辑文件
> 在 0Task.md 中添加新项目 "LZ058"

# 执行 shell 命令
> 执行 git status

# 退出
> /exit
# 或按 Ctrl+C
```

### 3.3 文件操作

```bash
# 读取文件
/read path/to/file.md

# 写入文件（覆盖）
/write path/to/file.md "内容"

# 追加内容
/append path/to/file.md "追加的内容"

# 编辑文件（智能替换）
/edit path/to/file.md "旧内容" "新内容"

# 搜索文件
/search "关键词"

# 列出目录
/ls path/to/dir
```

### 3.4 Git 操作

```bash
# 查看状态
> git status

# 添加文件
> git add .

# 提交（Claude 会自动生成提交信息）
> git commit -m "更新项目状态"

# 推送
> git push origin main

# 拉取更新
> git pull origin main

# 查看 diff
> git diff
```

---

## 4. 与 Obsidian 协同工作

### 4.1 核心工作流

#### 工作流 1: 生成法规报告

```bash
# 在 Claude Code 中
> 为 LZ057 项目生成工艺路线确认报告

Claude Code 会自动:
1. 读取 KB/03-outputs/templates/3-工艺路线确认报告.md
2. 搜索 KB/02-wiki/法规/ICH/Q11.md 相关条款
3. 查询 KB/04-projects/LZ057/ 现有资料
4. 生成报告并保存到 KB/03-outputs/报告/
5. 添加 YAML frontmatter
6. 创建双向链接 [[LZ057]] [[Q11]]
7. 执行 git commit
```

#### 工作流 2: 更新项目状态

```bash
# 在 Claude Code 中
> LZ057 已完成小试，进入中试阶段

Claude Code 会自动:
1. 更新 0Task.md 中项目状态
2. 创建中试方案文档（从模板）
3. 更新 KB/04-projects/LZ057/ 进度跟踪
4. 添加双向链接
5. git commit
```

#### 工作流 3: 法规查询

```bash
# 在 Claude Code 中
> 查询 Q3D 元素杂质指导原则

Claude Code 会:
1. 搜索 KB/02-wiki/法规/ICH/Q3D.md
2. 提取关键条款
3. 查找引用该法规的项目
4. 返回结构化答案
```

### 4.2 自定义命令（已预置）

| 命令 | 功能 | 示例 |
|------|------|------|
| `/search-kb` | 搜索知识库 | `/search-kb Q11` |
| `/generate-report` | 生成报告 | `/generate-report LZ057 3` |
| `/update-project` | 更新项目 | `/update-project LZ057 中试` |
| `/link-check` | 检查链接 | `/link-check` |
| `/sync-git` | Git 同步 | `/sync-git --push` |

### 4.3 YAML Frontmatter 规范

所有新文档必须包含：

```yaml
---
title: "文档标题"
description: "简要描述"
author: "Claude Code"
created: "2026-06-05"
modified: "2026-06-05"
tags:
  - 标签1
  - 标签2
status: draft | review | final
category: 法规 | 项目 | 报告 | 模板
project: "项目名称"
---
```

### 4.4 双向链接规范

```markdown
# 引用法规
[[ICH Q11]]
[[NMPA 变更指导原则]]

# 引用项目
[[LZ057]]
[[头孢噻肟钠]]

# 引用模板
[[工艺路线确认报告]]

# 引用经验案例
[[头孢呋辛酯发补答复]]
```

---

## 5. 高级功能

### 5.1 批量操作

```bash
# 批量重命名文件
> 将所有 "头孢" 开头的文件改为 "Cef"

# 批量更新链接
> 将文档中所有 [[Q11]] 改为 [[ICH Q11]]

# 批量生成报告
> 为所有活跃项目生成本周进度报告
```

### 5.2 代码执行

```bash
# 运行 Python 脚本
> 执行 python scripts/analyze_data.py

# 运行 Node.js 脚本
> 执行 node scripts/build-index.js

# 数据处理
> 读取 data.csv，统计每列的平均值
```

### 5.3 复杂查询

```bash
# 多条件搜索
> 搜索所有包含 "起始物料" 且状态为 "final" 的报告

# 跨文件分析
> 比较 LZ057 和 JP-1366 的工艺路线差异

# 生成摘要
> 总结 KB/02-wiki/法规/ICH/ 下所有文档的核心要点
```

---

## 6. 实战案例

### 案例 1: 从零生成完整报告

```bash
# 步骤 1: 确认项目存在
> 查看 0Task.md 中 LZ057 的状态

# 步骤 2: 生成报告
> /generate-report LZ057 3

# 步骤 3: 补充内容
> 在 KB/03-outputs/报告/LZ057-工艺路线确认报告-20260605.md 中添加 Q11 第 4.2 节引用

# 步骤 4: 更新状态
> 将报告状态改为 review

# 步骤 5: 提交
> /sync-git --push
```

### 案例 2: 法规更新同步

```bash
# 步骤 1: 获取新法规
> 在 KB/02-wiki/法规/ICH/ 下创建 Q3E.md

# 步骤 2: 提取关键信息
> 总结 Q3E 的核心要求和与 Q3D 的区别

# 步骤 3: 更新索引
> 更新 KB/README.md，添加 Q3E 到目录

# 步骤 4: 通知相关项目
> 哪些项目需要关注 Q3E？列出并通知负责人

# 步骤 5: 提交
> git add . && git commit -m "新增 ICH Q3E 指导原则" && git push
```

### 案例 3: 项目状态全面更新

```bash
# 步骤 1: 查看当前状态
> 读取 0Task.md

# 步骤 2: 更新多个项目
> /update-project 头孢噻肟钠 申报资料定稿
> /update-project 米诺地尔 中试等待
> /update-project 西酞普兰 立项签批中

# 步骤 3: 生成本周汇总
> 生成本周所有项目进度汇总报告

# 步骤 4: 提交
> /sync-git --push
```

---

## 7. 故障排除

### 7.1 安装问题

**问题**: `npm install` 失败
```bash
# 解决: 清除缓存重试
npm cache clean --force
npm install -g @anthropic-ai/claude-code
```

**问题**: `claude: command not found`
```bash
# 解决: 检查 npm 全局路径
npm config get prefix
# 将输出路径添加到 PATH
export PATH="$PATH:$(npm config get prefix)/bin"
```

### 7.2 登录问题

**问题**: 浏览器登录后无响应
```bash
# 解决: 手动复制 token
# 1. 浏览器登录后，复制页面上的 token
# 2. 在终端输入
claude --token YOUR_TOKEN_HERE
```

### 7.3 文件操作问题

**问题**: 无法读取中文文件名
```bash
# 解决: 设置编码
export LANG=zh_CN.UTF-8
export LC_ALL=zh_CN.UTF-8
```

**问题**: 权限不足
```bash
# 解决: 检查文件权限
ls -la file.md
chmod 644 file.md
```

### 7.4 Git 同步问题

**问题**: 冲突无法解决
```bash
# 在 Claude Code 中
> 解决 git 冲突，保留本地修改

# 或手动
> git status
> git diff
> 编辑冲突文件
> git add .
> git commit -m "解决冲突"
```

### 7.5 网络问题

**问题**: API 请求超时
```bash
# 解决: 检查网络
ping api.anthropic.com

# 或使用代理
export HTTPS_PROXY=http://proxy.company.com:8080
claude
```

---

## 8. 快捷键与技巧

### 8.1 终端快捷键

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+C` | 中断当前操作 |
| `Ctrl+D` | 退出 Claude Code |
| `Tab` | 自动补全 |
| `↑` / `↓` | 历史命令 |
| `Ctrl+R` | 搜索历史 |

### 8.2 高效提示技巧

```bash
# ❌ 低效
> 帮我改一下文件

# ✅ 高效
> 在 KB/03-outputs/报告/LZ057-工艺路线确认报告-20260605.md 中，
  第 3 节 "合成路线" 下添加一段关于起始物料选择的说明，
  引用 ICH Q11 第 4.2 节，约 200 字

# ❌ 低效
> 搜索一下

# ✅ 高效
> 在 KB/02-wiki/法规/ICH/ 目录下搜索所有包含 "基因毒性杂质" 的文档，
  按修改时间排序，显示前 5 个结果
```

### 8.3 批量操作技巧

```bash
# 使用通配符
> 读取 KB/04-projects/*/进度跟踪.md

# 使用条件
> 找出所有 status 为 draft 且创建时间超过 7 天的文档

# 批量修改
> 将所有文档中的 "2026-06-05" 改为 "2026-06-06"
```

### 8.4 与 Obsidian 联动技巧

```bash
# 在 Claude Code 中编辑后，Obsidian 实时刷新
# 确保 Obsidian 中开启 "自动保存"

# 使用 Obsidian URL 快速定位
> 生成 Obsidian URL: obsidian://open?vault=KB&file=02-wiki/法规/ICH/Q11

# 在 Obsidian 中查看图谱
# 打开 Graph View，查看新创建的链接关系
```

---

## 附录

### A. 完整命令参考

```bash
# 文件操作
/read <file>              # 读取文件
/write <file> <content>   # 写入文件
/append <file> <content>  # 追加内容
/edit <file> <old> <new>  # 编辑文件
/search <query>           # 搜索内容
/ls <dir>                 # 列出目录

# Git 操作
git <command>             # 执行 git 命令

# 系统操作
/execute <command>        # 执行 shell 命令

# 其他
/exit                     # 退出
/help                     # 帮助
```

### B. 配置文件参考

```yaml
# .claude/CLAUDE.md
# 自定义指令文件，定义 Claude Code 的行为规范

# .claude/commands/
# 自定义命令目录，可添加常用操作

# scripts/
# 辅助脚本目录，包含启动、同步、备份脚本
```

### C. 相关资源

- [Claude Code 官方文档](https://docs.anthropic.com/claude-code)
- [Obsidian 官方文档](https://help.obsidian.md)
- [Git 教程](https://git-scm.com/doc)

---

*本教程由小虾编写，版本 v1.0*
*有问题随时在飞书 @我*
